package com.example.reversekeyboard

import android.content.Context

/** الإيموجي الكاملة (~1900) + البحث + بدائل لون البشرة، من ملفات assets. */
object Emojis {
    /** التبويب الأول "الأخيرة" يُملأ من الاستخدام. */
    var categories: List<Pair<String, List<String>>> = listOf("🕘" to emptyList())
        private set
    private var loaded = false
    private var searchLoaded = false
    private val searchEmoji = ArrayList<String>()
    private val searchText = ArrayList<String>()
    private val tones = HashMap<String, String>()

    private const val LIGHT = "🏻"
    private val TONES = listOf("🏻", "🏼", "🏽", "🏾", "🏿")

    fun load(ctx: Context) {
        if (loaded) return
        try {
            val out = ArrayList<Pair<String, List<String>>>()
            out.add("🕘" to emptyList())
            ctx.assets.open("emojis.txt").bufferedReader(Charsets.UTF_8).useLines { lines ->
                lines.forEach { l ->
                    val p = l.split('\t')
                    if (p.size == 2 && p[1].isNotBlank())
                        out.add(p[0] to p[1].trim().split(' ').filter { it.isNotEmpty() })
                }
            }
            if (out.size > 1) { categories = out; loaded = true }
        } catch (_: Exception) { }
        try {
            ctx.assets.open("emoji_tone.txt").bufferedReader(Charsets.UTF_8).useLines { lines ->
                lines.forEach { l ->
                    val p = l.split('\t')
                    if (p.size == 2) tones[p[0]] = p[1]
                }
            }
        } catch (_: Exception) { }
    }

    /** الإيموجي نفسه + 5 درجات بشرة، أو null إذا ما يدعم. */
    fun toneVariants(e: String): List<String>? {
        val light = tones[e] ?: return null
        return listOf(e) + TONES.map { light.replace(LIGHT, it) }
    }

    private fun loadSearch(ctx: Context) {
        if (searchLoaded) return
        try {
            ctx.assets.open("emoji_search.txt").bufferedReader(Charsets.UTF_8).useLines { lines ->
                lines.forEach { l ->
                    val i = l.indexOf('\t')
                    if (i > 0) { searchEmoji.add(l.substring(0, i)); searchText.add(l.substring(i + 1)) }
                }
            }
            searchLoaded = true
        } catch (_: Exception) { }
    }

    // كلمات عربية شائعة ← مقابلها الإنجليزي (البحث في أسماء الإيموجي الإنجليزية)
    private val ar = mapOf(
        "ضحك" to "laugh", "يضحك" to "laugh", "ضحكة" to "laugh", "ابتسامة" to "smile", "ابتسام" to "smile", "يبتسم" to "smile",
        "حزين" to "sad", "حزن" to "sad", "بكاء" to "cry", "يبكي" to "cry", "دموع" to "tear", "قلب" to "heart", "قلوب" to "heart",
        "حب" to "love", "احبك" to "love", "عشق" to "love", "نار" to "fire", "حريق" to "fire", "وجه" to "face", "يد" to "hand",
        "اصبع" to "finger", "اصابع" to "finger", "ورد" to "flower", "وردة" to "rose", "زهرة" to "flower", "شمس" to "sun",
        "قمر" to "moon", "نجمة" to "star", "نجوم" to "star", "سيارة" to "car", "سياره" to "car", "طيارة" to "airplane",
        "طائرة" to "airplane", "قطة" to "cat", "قط" to "cat", "كلب" to "dog", "حصان" to "horse", "اسد" to "lion", "ثعبان" to "snake",
        "سمكة" to "fish", "سمك" to "fish", "طير" to "bird", "عصفور" to "bird", "اكل" to "food", "طعام" to "food", "قهوة" to "coffee",
        "شاي" to "tea", "ماء" to "water", "مويه" to "water", "كرة" to "ball", "كورة" to "soccer", "مال" to "money", "فلوس" to "money",
        "هدية" to "gift", "جوال" to "phone", "هاتف" to "phone", "تلفون" to "phone", "كتاب" to "book", "ساعة" to "clock",
        "بيت" to "house", "منزل" to "house", "مسجد" to "mosque", "كعبة" to "kaaba", "علم" to "flag", "غضب" to "angry",
        "غاضب" to "angry", "خوف" to "fear", "خايف" to "fear", "نوم" to "sleep", "نايم" to "sleep", "مريض" to "sick", "مرض" to "sick",
        "تفكير" to "thinking", "يفكر" to "thinking", "تصفيق" to "clap", "دعاء" to "pray", "دعا" to "pray", "شكرا" to "thanks",
        "موافق" to "ok", "تمام" to "ok", "ممتاز" to "ok", "بطيخ" to "watermelon", "موز" to "banana", "تفاح" to "apple",
        "برتقال" to "orange", "فراولة" to "strawberry", "بيتزا" to "pizza", "برجر" to "burger", "كيك" to "cake", "حلويات" to "sweet",
        "شجرة" to "tree", "مطر" to "rain", "ثلج" to "snow", "غيم" to "cloud", "سحاب" to "cloud", "بحر" to "sea", "جبل" to "mountain",
        "رجل" to "man", "امرأة" to "woman", "مرأة" to "woman", "بنت" to "girl", "ولد" to "boy", "طفل" to "baby", "رضيع" to "baby",
        "عين" to "eye", "عيون" to "eyes", "فم" to "mouth", "اذن" to "ear", "انف" to "nose", "قدم" to "foot", "عضلات" to "muscle",
        "قوة" to "muscle", "تاج" to "crown", "ملك" to "king", "ملكة" to "queen", "مبروك" to "party", "حفلة" to "party", "عيد" to "party",
        "بالون" to "balloon", "موسيقى" to "music", "اغنية" to "music", "ميكروفون" to "microphone", "كاميرا" to "camera",
        "صورة" to "camera", "فيديو" to "video", "حاسوب" to "computer", "لابتوب" to "laptop", "مفتاح" to "key", "قفل" to "lock",
        "سلاح" to "gun", "سيف" to "sword", "قنبلة" to "bomb", "جمجمة" to "skull", "شبح" to "ghost", "روبوت" to "robot",
        "فضائي" to "alien", "عفريت" to "devil", "شيطان" to "devil", "ملاك" to "angel", "قرد" to "monkey", "فيل" to "elephant",
        "دب" to "bear", "ارنب" to "rabbit", "بقرة" to "cow", "خروف" to "sheep", "جمل" to "camel", "دجاجة" to "chicken",
        "دجاج" to "chicken", "فراشة" to "butterfly", "نحلة" to "bee", "عنكبوت" to "spider", "تمر" to "date", "نخلة" to "palm",
        "صح" to "check", "خطأ" to "cross", "سؤال" to "question", "تعجب" to "exclamation", "سهم" to "arrow", "رقم" to "number",
        "ممنوع" to "prohibited", "تحذير" to "warning", "سلام" to "wave", "مرحبا" to "wave", "وداع" to "wave", "هلا" to "wave",
        "فخر" to "proud", "خجل" to "blush", "مفاجأة" to "surprised", "صدمة" to "shocked", "قبلة" to "kiss", "بوسة" to "kiss",
        "مزح" to "wink", "غمزة" to "wink", "جوع" to "hungry", "جعان" to "hungry", "عطشان" to "thirst", "برد" to "cold", "حر" to "hot"
    )

    private fun normAr(s: String): String {
        val sb = StringBuilder()
        for (c in s) {
            if (c in 'ً'..'ٟ' || c == 'ـ') continue
            sb.append(when (c) { 'أ', 'إ', 'آ' -> 'ا'; 'ة' -> 'ه'; 'ى' -> 'ي'; else -> c })
        }
        return sb.toString()
    }

    private val arNorm by lazy { ar.mapKeys { normAr(it.key) } }

    fun search(ctx: Context, query: String, max: Int = 60): List<String> {
        loadSearch(ctx)
        val q = query.trim().lowercase()
        if (q.isEmpty() || searchEmoji.isEmpty()) return emptyList()
        val tokens = q.split(Regex("\\s+")).filter { it.isNotEmpty() }.map { t ->
            if (t.any { it.code > 127 }) {
                val n = normAr(t)
                arNorm[n] ?: arNorm[n.removePrefix("ال")] ?: t
            } else t
        }
        val scored = ArrayList<Pair<Int, Int>>()
        for (i in searchText.indices) {
            val txt = searchText[i]
            var score = 0; var ok = true
            for (t in tokens) {
                val at = txt.indexOf(t)
                if (at < 0) { ok = false; break }
                // مطابقة بداية الاسم أو بداية كلمة أفضل
                score += if (at == 0) 0 else if (txt[at - 1] == ' ') 20 else 60
            }
            if (ok) scored.add(Pair(score * 10000 + i, i))
        }
        scored.sortBy { it.first }
        return scored.take(max).map { searchEmoji[it.second] }
    }
}
