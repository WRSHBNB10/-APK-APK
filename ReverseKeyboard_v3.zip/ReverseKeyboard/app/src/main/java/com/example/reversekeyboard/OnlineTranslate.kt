package com.example.reversekeyboard

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/** ترجمة عبر الإنترنت (أدق بكثير من الترجمة المحلية). تُستدعى من خيط خلفي فقط. */
object OnlineTranslate {

    private fun post(url: String, body: String, contentType: String, headers: Map<String, String> = emptyMap()): String {
        val c = URL(url).openConnection() as HttpURLConnection
        try {
            c.requestMethod = "POST"
            c.connectTimeout = 8000
            c.readTimeout = 20000
            c.doOutput = true
            c.setRequestProperty("Content-Type", contentType)
            headers.forEach { (k, v) -> c.setRequestProperty(k, v) }
            c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            val code = c.responseCode
            val stream = if (code in 200..299) c.inputStream else c.errorStream
            val text = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
            if (code !in 200..299) throw RuntimeException("HTTP $code")
            return text
        } finally {
            c.disconnect()
        }
    }

    /** ترجمة Google (نفس محرك Google Translate). */
    fun google(text: String, toEnglish: Boolean): String {
        val tl = if (toEnglish) "en" else "ar"
        val body = "q=" + URLEncoder.encode(text, "UTF-8")
        val resp = post(
            "https://translate.googleapis.com/translate_a/single?client=gtx&sl=auto&tl=$tl&dt=t",
            body, "application/x-www-form-urlencoded;charset=UTF-8"
        )
        val parts = JSONArray(resp).getJSONArray(0)
        val sb = StringBuilder()
        for (i in 0 until parts.length()) {
            val seg = parts.optJSONArray(i) ?: continue
            sb.append(seg.optString(0, ""))
        }
        val out = sb.toString().trim()
        if (out.isEmpty()) throw RuntimeException("empty")
        return out
    }

    /** ترجمة Claude: الأفضل للعامية والسياق (يحتاج مفتاح API من المستخدم). */
    fun claude(apiKey: String, text: String, toEnglish: Boolean): String {
        val target = if (toEnglish) "English" else "Arabic"
        val prompt = "Translate the following text into natural, fluent $target. " +
            "Keep the meaning, tone, slang and dialect (Gulf Arabic is common) and keep emojis, numbers and line breaks. " +
            "Output ONLY the translation, no quotes or explanations.\n\n" + text
        val req = JSONObject()
            .put("model", "claude-haiku-5-5")
            .put("max_tokens", 2048)
            .put("messages", JSONArray().put(JSONObject().put("role", "user").put("content", prompt)))
        val resp = post(
            "https://api.anthropic.com/v1/messages", req.toString(), "application/json",
            mapOf("x-api-key" to apiKey, "anthropic-version" to "2023-06-01")
        )
        val out = JSONObject(resp).getJSONArray("content").getJSONObject(0).getString("text").trim()
        if (out.isEmpty()) throw RuntimeException("empty")
        return out
    }
}
