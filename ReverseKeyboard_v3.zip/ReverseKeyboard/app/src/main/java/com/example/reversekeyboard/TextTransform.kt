package com.example.reversekeyboard

enum class Mode(val label: String) {
    NORMAL("عادي"),
    ARABIZI("إنجليزي"),
    REVERSE("عكس"),
    NODOTS("بدون نقاط"),
    BOTH("عكس + بدون نقاط")
}

object TextTransform {

    fun apply(s: String, mode: Mode): String = when (mode) {
        Mode.NORMAL -> s
        Mode.ARABIZI -> arabizi(s)
        Mode.REVERSE -> reverse(s)
        Mode.NODOTS -> removeDots(s)
        Mode.BOTH -> reverse(removeDots(s))
    }

    /** يفكّ العكس: كل سطر لحاله، وتبقى الحركات فوق حروفها. */
    fun unreverse(s: String): String = s.split("\n").joinToString("\n") { line ->
        val r = StringBuilder(line).reverse()
        val out = StringBuilder()
        var i = 0
        while (i < r.length) {
            if (isHaraka(r[i])) {
                // بعد العكس صارت الحركة قبل حرفها، نرجعها بعده
                var j = i
                while (j < r.length && isHaraka(r[j])) j++
                if (j < r.length) { out.append(r[j]); out.append(r, i, j); i = j + 1; continue }
            }
            out.append(r[i]); i++
        }
        out.toString()
    }

    fun reverse(s: String): String = StringBuilder(s).reverse().toString()

    private fun isArabicLetter(c: Char) = c in '\u0621'..'\u064A' || c in '\u066E'..'\u06D3'

    private fun isHaraka(c: Char) = c in '\u064B'..'\u065F' || c == '\u0670'

    private fun isFinal(s: String, index: Int): Boolean {
        var i = index + 1
        while (i < s.length && isHaraka(s[i])) i++
        return i >= s.length || !isArabicLetter(s[i])
    }

    /** عمي ← عمى */
    fun removeDots(s: String): String {
        val sb = StringBuilder()
        for (i in s.indices) {
            val c = s[i]
            val last = isFinal(s, i)
            sb.append(
                when (c) {
                    'ب', 'ت', 'ث' -> '\u066E'
                    'ن' -> if (last) '\u06BA' else '\u066E'
                    'ي' -> if (last) 'ى' else '\u066E'
                    'ج', 'خ' -> 'ح'
                    'ذ' -> 'د'
                    'ز' -> 'ر'
                    'ش' -> 'س'
                    'ض' -> 'ص'
                    'ظ' -> 'ط'
                    'غ' -> 'ع'
                    'ف' -> '\u06A1'
                    'ق' -> if (last) '\u066F' else '\u06A1'
                    'ة' -> 'ه'
                    else -> c
                }
            )
        }
        return sb.toString()
    }

    // ---------- عربي ← حروف إنجليزية (تمام ← tmam) ----------

    private fun isArabicLetterOnly(c: Char) = isArabicLetter(c) && !isHaraka(c)

    private fun isAlef(c: Char) = c == 'ا' || c == 'أ' || c == 'إ' || c == 'آ' || c == 'ى'

    private fun prevLetter(s: String, i: Int): Char? {
        var j = i - 1
        while (j >= 0 && (isHaraka(s[j]) || s[j] == '\u0640')) j--
        return if (j >= 0 && isArabicLetter(s[j])) s[j] else null
    }

    private fun nextLetter(s: String, i: Int): Char? {
        var j = i + 1
        while (j < s.length && (isHaraka(s[j]) || s[j] == '\u0640')) j++
        return if (j < s.length && isArabicLetter(s[j])) s[j] else null
    }

    fun arabizi(s: String): String {
        val sb = StringBuilder()
        for (i in s.indices) {
            val c = s[i]
            if (isHaraka(c) || c == '\u0640') continue
            val prev = prevLetter(s, i)
            val next = nextLetter(s, i)
            val afterAlef = prev != null && isAlef(prev)
            val beforeAlef = next != null && isAlef(next)
            sb.append(
                when (c) {
                    'ا', 'آ' -> "a"
                    'أ' -> "a"
                    'إ' -> "i"
                    'ى' -> "a"
                    'ء' -> "2"
                    'ئ' -> "i"
                    'ؤ' -> "o"
                    'ب' -> "b"
                    'ت' -> "t"
                    'ث' -> "th"
                    'ج' -> "j"
                    'ح' -> "7"
                    'خ' -> "5"
                    'د' -> "d"
                    'ذ' -> "dh"
                    'ر' -> "r"
                    'ز' -> "z"
                    'س' -> "s"
                    'ش' -> "sh"
                    'ص' -> "9"
                    'ض' -> "d"
                    'ط' -> "6"
                    'ظ' -> "6"
                    'ع' -> "3"
                    'غ' -> "gh"
                    'ف' -> "f"
                    'ق' -> "q"
                    'ك' -> "k"
                    'ل' -> "l"
                    'م' -> "m"
                    'ن' -> "n"
                    'ه' -> "h"
                    'ة' -> "h"
                    'و' -> if (prev == null || afterAlef || beforeAlef) "w" else "o"
                    'ي' -> if (prev == null || afterAlef || beforeAlef) "y" else "i"
                    '،' -> ","
                    '؟' -> "?"
                    '؛' -> ";"
                    else -> c.toString()
                }
            )
        }
        return sb.toString()
    }
}
