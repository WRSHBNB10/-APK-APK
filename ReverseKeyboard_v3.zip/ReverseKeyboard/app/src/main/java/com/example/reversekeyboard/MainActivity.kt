package com.example.reversekeyboard

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.CheckBox
import android.widget.SeekBar
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (24 * resources.displayMetrics.density).toInt()

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }

        layout.addView(TextView(this).apply {
            text = "1) فعّل الكيبورد  2) اختره  3) جرّبه في الخانة تحت"
            textSize = 16f
        })

        layout.addView(Button(this).apply {
            text = "تفعيل الكيبورد"
            setOnClickListener { startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS)) }
        })

        layout.addView(Button(this).apply {
            text = "اختيار الكيبورد"
            setOnClickListener {
                (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager)
                    .showInputMethodPicker()
            }
        })

        val prefs = getSharedPreferences("kb", Context.MODE_PRIVATE)
        layout.addView(CheckBox(this).apply {
            text = "صوت الضغط"
            isChecked = prefs.getBoolean("sound", true)
            setOnCheckedChangeListener { _, v -> prefs.edit().putBoolean("sound", v).apply() }
        })
        layout.addView(CheckBox(this).apply {
            text = "اقتراحات الكلمات"
            isChecked = prefs.getBoolean("suggest", true)
            setOnCheckedChangeListener { _, v -> prefs.edit().putBoolean("suggest", v).apply() }
        })
        layout.addView(CheckBox(this).apply {
            text = "التصحيح التلقائي للكلمات الخاطئة (اختياري — اضغط ⌫ مباشرة بعد التصحيح للتراجع عنه)"
            isChecked = prefs.getBoolean("autocorrect", false)
            setOnCheckedChangeListener { _, v -> prefs.edit().putBoolean("autocorrect", v).apply() }
        })
        layout.addView(CheckBox(this).apply {
            text = "الكتابة بالسحب على الحروف"
            isChecked = prefs.getBoolean("glide", true)
            setOnCheckedChangeListener { _, v -> prefs.edit().putBoolean("glide", v).apply() }
        })
        layout.addView(CheckBox(this).apply {
            text = "تحريك المؤشر بسحب مسطرة المسافة"
            isChecked = prefs.getBoolean("space_slide", true)
            setOnCheckedChangeListener { _, v -> prefs.edit().putBoolean("space_slide", v).apply() }
        })
        layout.addView(TextView(this).apply { text = "ثيم الكيبورد" })
        layout.addView(android.widget.Spinner(this).apply {
            val keys = Theme.all.keys.toList()
            adapter = android.widget.ArrayAdapter(
                this@MainActivity, android.R.layout.simple_spinner_dropdown_item, Theme.all.values.map { it.label })
            setSelection(keys.indexOf(prefs.getString("theme", "blue")).coerceAtLeast(0))
            onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
                override fun onItemSelected(p: android.widget.AdapterView<*>?, v: android.view.View?, pos: Int, id: Long) {
                    prefs.edit().putString("theme", keys[pos]).apply()
                }
                override fun onNothingSelected(p: android.widget.AdapterView<*>?) {}
            }
        })
        layout.addView(TextView(this).apply { text = "وضع اليد الواحدة" })
        layout.addView(android.widget.Spinner(this).apply {
            val keys = listOf("off", "right", "left")
            adapter = android.widget.ArrayAdapter(
                this@MainActivity, android.R.layout.simple_spinner_dropdown_item,
                listOf("إيقاف", "يمين", "يسار"))
            setSelection(keys.indexOf(prefs.getString("onehand", "off")).coerceAtLeast(0))
            onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
                override fun onItemSelected(p: android.widget.AdapterView<*>?, v: android.view.View?, pos: Int, id: Long) {
                    prefs.edit().putString("onehand", keys[pos]).apply()
                }
                override fun onNothingSelected(p: android.widget.AdapterView<*>?) {}
            }
        })
        layout.addView(TextView(this).apply { text = "ارتفاع الكيبورد (70% – 140%)" })
        layout.addView(SeekBar(this).apply {
            max = 70
            progress = prefs.getInt("kb_scale", 100) - 70
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) {
                    prefs.edit().putInt("kb_scale", p + 70).apply()
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        })
        layout.addView(CheckBox(this).apply {
            text = "حفظ سجل الحافظة"
            isChecked = prefs.getBoolean("clip_history", true)
            setOnCheckedChangeListener { _, v -> prefs.edit().putBoolean("clip_history", v).apply() }
        })
        layout.addView(Button(this).apply {
            text = "مسح سجل الحافظة"
            setOnClickListener {
                prefs.edit().remove("clips").remove("clip_last").apply()
                android.widget.Toast.makeText(this@MainActivity, "تم المسح", android.widget.Toast.LENGTH_SHORT).show()
            }
        })
        layout.addView(TextView(this).apply {
            text = "مفتاح Claude API (اختياري، لأدق ترجمة — بدونه تستخدم ترجمة Google)"
        })
        layout.addView(EditText(this).apply {
            hint = "sk-ant-..."
            setText(prefs.getString("claude_key", ""))
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD
            addTextChangedListener(object : android.text.TextWatcher {
                override fun afterTextChanged(e: android.text.Editable?) {
                    prefs.edit().putString("claude_key", e?.toString()?.trim().orEmpty()).apply()
                }
                override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
                override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            })
        })
        layout.addView(TextView(this).apply { text = "مستوى الصوت" })
        layout.addView(SeekBar(this).apply {
            max = 100
            progress = prefs.getInt("volume", 70)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) {
                    prefs.edit().putInt("volume", p).apply()
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        })

        layout.addView(EditText(this).apply {
            hint = "جرّب الكتابة هنا"
            minLines = 3
        })

        setContentView(layout)
    }
}
