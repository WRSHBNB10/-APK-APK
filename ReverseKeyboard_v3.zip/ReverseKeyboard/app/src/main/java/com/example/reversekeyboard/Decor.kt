package com.example.reversekeyboard

/** زخرفة النصوص: حروف إنجليزية بأشكال يونيكود + زخارف عربية (تطويل، حركات، إطارات). */
object Decor {

    private fun mapLatin(
        s: String, upper: Int, lower: Int, digit: Int? = null,
        exc: Map<Char, String> = emptyMap()
    ): String {
        val sb = StringBuilder()
        for (c in s) {
            val e = exc[c]
            when {
                e != null -> sb.append(e)
                c in 'A'..'Z' -> sb.appendCodePoint(upper + (c - 'A'))
                c in 'a'..'z' -> sb.appendCodePoint(lower + (c - 'a'))
                c in '0'..'9' && digit != null -> sb.appendCodePoint(digit + (c - '0'))
                else -> sb.append(c)
            }
        }
        return sb.toString()
    }

    private const val NON_JOIN = "ادذرزوؤةىأإآء"
    private fun isAr(c: Char) = c in 'ء'..'ي'

    private fun tatweel(s: String, n: Int): String {
        val sb = StringBuilder()
        for (i in s.indices) {
            val c = s[i]
            sb.append(c)
            if (isAr(c) && c !in NON_JOIN && i + 1 < s.length && isAr(s[i + 1])) repeat(n) { sb.append('ـ') }
        }
        return sb.toString()
    }

    private fun harakat(s: String): String {
        val marks = listOf("َ", "ُ", "ِ", "ْ")
        var k = 0
        val sb = StringBuilder()
        for (i in s.indices) {
            val c = s[i]
            sb.append(c)
            if (isAr(c) && c != 'ء') {
                sb.append(marks[k++ % marks.size])
                if (c !in NON_JOIN && i + 1 < s.length && isAr(s[i + 1])) sb.append('ـ')
            }
        }
        return sb.toString()
    }

    private fun combine(s: String, mark: Char) = buildString {
        for (c in s) { append(c); if (!c.isWhitespace()) append(mark) }
    }

    private fun frame(l: String, r: String) = { s: String -> "$l $s $r" }

    private val smallCaps = "ᴀʙᴄᴅᴇꜰɢʜɪᴊᴋʟᴍɴᴏᴘǫʀꜱᴛᴜᴠᴡxʏᴢ"

    private val circledDigits = mapOf(
        '0' to "⓪", '1' to "①", '2' to "②", '3' to "③", '4' to "④",
        '5' to "⑤", '6' to "⑥", '7' to "⑦", '8' to "⑧", '9' to "⑨"
    )
    private val doubleStruckExc = mapOf(
        'C' to "ℂ", 'H' to "ℍ", 'N' to "ℕ", 'P' to "ℙ", 'Q' to "ℚ", 'R' to "ℝ", 'Z' to "ℤ"
    )

    val styles: List<Pair<String, (String) -> String>> = listOf(
        // ----- عربي -----
        "تطويل" to { s: String -> tatweel(s, 1) },
        "تطويل كبير" to { s: String -> tatweel(s, 3) },
        "حركات وتطويل" to { s: String -> harakat(s) },
        "إطار ﴿ ﴾" to { s: String -> "﴿ ${tatweel(s, 2)} ﴾" },
        "إطار ꧁ ꧂" to { s: String -> "꧁ ${tatweel(s, 2)} ꧂" },
        "إطار ✿" to { s: String -> "✿ ${tatweel(s, 2)} ✿" },
        "إطار ★彡" to { s: String -> "★彡 ${tatweel(s, 2)} 彡★" },
        "إطار 【 】" to { s: String -> "【 ${tatweel(s, 1)} 】" },
        "إطار 『 』" to { s: String -> "『 ${tatweel(s, 1)} 』" },
        "إطار ⚜" to { s: String -> "⚜ ${tatweel(s, 2)} ⚜" },
        "إطار ♥" to { s: String -> "♥ ${tatweel(s, 2)} ♥" },
        "إطار ❖" to { s: String -> "❖ ${tatweel(s, 2)} ❖" },
        // ----- إنجليزي -----
        "عريض" to { s: String -> mapLatin(s, 0x1D400, 0x1D41A, 0x1D7CE) },
        "مائل" to { s: String -> mapLatin(s, 0x1D434, 0x1D44E, null, mapOf('h' to "ℎ")) },
        "عريض مائل" to { s: String -> mapLatin(s, 0x1D468, 0x1D482, 0x1D7CE) },
        "خط يد" to { s: String -> mapLatin(s, 0x1D4D0, 0x1D4EA, 0x1D7CE) },
        "قوطي" to { s: String -> mapLatin(s, 0x1D56C, 0x1D586, 0x1D7CE) },
        "مفرّغ" to { s: String -> mapLatin(s, 0x1D538, 0x1D552, 0x1D7D8, doubleStruckExc) },
        "آلة كاتبة" to { s: String -> mapLatin(s, 0x1D670, 0x1D68A, 0x1D7F6) },
        "سانس عريض" to { s: String -> mapLatin(s, 0x1D5D4, 0x1D5EE, 0x1D7EC) },
        "دوائر" to { s: String -> mapLatin(s, 0x24B6, 0x24D0, null, circledDigits) },
        "مربعات" to { s: String -> mapLatin(s, 0x1F130, 0x1F130) },
        "عريض الحجم" to { s: String -> mapLatin(s, 0xFF21, 0xFF41, 0xFF10) },
        "كابتل صغير" to { s: String ->
            buildString { for (c in s) { val l = c.lowercaseChar(); append(if (l in 'a'..'z') smallCaps[l - 'a'] else c) } }
        },
        // ----- للاثنين -----
        "متباعد" to { s: String -> s.toList().joinToString(" ") },
        "مشطوب" to { s: String -> combine(s, '̶') },
        "تحته خط" to { s: String -> combine(s, '̲') },
        "نجوم بين الحروف" to { s: String -> s.toList().joinToString("★") },
        "قلوب بين الكلمات" to { s: String -> s.trim().split(Regex("\\s+")).joinToString(" ♥ ") }
    )
}
