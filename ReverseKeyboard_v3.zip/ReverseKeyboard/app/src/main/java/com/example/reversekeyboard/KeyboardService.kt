package com.example.reversekeyboard

import android.Manifest
import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.Translator
import com.google.mlkit.nl.translate.TranslatorOptions
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.inputmethodservice.InputMethodService
import android.media.AudioAttributes
import android.media.SoundPool
import android.provider.Settings
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.view.KeyEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.LinearLayout

class KeyboardService : InputMethodService() {

    private val POPUP_AREA = 56

    private enum class Page { AR, EN, SYM1, SYM2, NUM, EMOJI, CLIP, DECOR }

    private val buffer = StringBuilder()
    private var mode = Mode.NORMAL
    private var page = Page.AR
    private var lastLetterPage = Page.AR
    private var shift = false
    private var caps = false
    private var lastShiftTap = 0L

    private lateinit var root: LinearLayout
    private lateinit var keysBox: LinearLayout
    private lateinit var modeButton: android.widget.TextView
    private lateinit var overlay: android.widget.FrameLayout
    private var clipListener: android.content.ClipboardManager.OnPrimaryClipChangedListener? = null
    private lateinit var transRow: LinearLayout
    private lateinit var transText: android.widget.TextView
    private var showTrans = false
    private var transResult: String? = null
    private var transSelected = false
    private var transBeforeLen = 0
    private var transAfterLen = 0
    private var transToken = 0
    private val translators = HashMap<String, Translator>()
    private lateinit var harakatRow: LinearLayout
    private var showHarakat = false
    private val harakat = listOf("\u064E", "\u064F", "\u0650", "\u0651", "\u0652", "\u064B", "\u064C", "\u064D")
    private lateinit var toolsRow: LinearLayout
    private lateinit var toolsScroll: android.widget.HorizontalScrollView
    private lateinit var micButton: android.widget.TextView
    private var recognizer: SpeechRecognizer? = null
    private var listening = false
    private lateinit var sugRow: LinearLayout
    private var emojiSearch = false
    private val emojiQuery = StringBuilder()
    private lateinit var emojiSearchRow: LinearLayout
    private lateinit var emojiQueryTv: android.widget.TextView
    private lateinit var emojiResultsBox: LinearLayout
    private var glideAlt: List<String>? = null
    private var glideLen = 0
    private var autoUndo: Array<String>? = null
    private val sugViews = mutableListOf<android.widget.TextView>()
    private var currentSug: List<String> = emptyList()
    private var currentWordLen = 0
    private var suggestOk = true
    private val uiHandler = Handler(Looper.getMainLooper())
    private val updateRunnable = Runnable { updateSuggestions() }
    private val suggestions by lazy { Suggestions(this, prefs) }
    private val letterKeys = mutableListOf<Pair<KeyView, String>>()
    private var shiftKey: KeyView? = null

    // ---------- الصوت ----------
    private lateinit var pool: SoundPool
    private val sounds = IntArray(4)
    private val prefs by lazy { getSharedPreferences("kb", Context.MODE_PRIVATE) }

    override fun onCreate() {
        super.onCreate()
        pool = SoundPool.Builder()
            .setMaxStreams(4)
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build()
            ).build()
        sounds[0] = pool.load(this, R.raw.key_standard, 1)
        sounds[1] = pool.load(this, R.raw.key_space, 1)
        sounds[2] = pool.load(this, R.raw.key_delete, 1)
        sounds[3] = pool.load(this, R.raw.key_enter, 1)
        lastLetterPage = if (prefs.getString("last_lang", "ar") == "en") Page.EN else Page.AR
        page = lastLetterPage
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
        clipListener = android.content.ClipboardManager.OnPrimaryClipChangedListener { captureClip() }
        cm.addPrimaryClipChangedListener(clipListener)
    }

    override fun onDestroy() {
        clipListener?.let {
            (getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager)
                .removePrimaryClipChangedListener(it)
        }
        translators.values.forEach { try { it.close() } catch (_: Exception) {} }
        stopVoice()
        pool.release()
        super.onDestroy()
    }

    private fun playSound(type: Int) {
        if (!prefs.getBoolean("sound", true)) return
        val sys = Settings.System.getInt(contentResolver, Settings.System.SOUND_EFFECTS_ENABLED, 1)
        if (sys == 0) return
        val v = prefs.getInt("volume", 70) / 100f
        pool.play(sounds[type], v, v, 1, 0, 1f)
    }

    // ---------- التخطيطات (من اليسار لليمين مثل Gboard) ----------
    private val arRows = listOf(
        listOf("ض", "ص", "ث", "ق", "ف", "غ", "ع", "ه", "خ", "ح", "ج"),
        listOf("ش", "س", "ي", "ب", "ل", "ا", "ت", "ن", "م", "ك", "ط"),
        listOf("ذ", "ء", "ؤ", "ر", "ى", "ة", "و", "ز", "ظ", "د")
    )
    private val enRows = listOf(
        listOf("q", "w", "e", "r", "t", "y", "u", "i", "o", "p"),
        listOf("a", "s", "d", "f", "g", "h", "j", "k", "l"),
        listOf("z", "x", "c", "v", "b", "n", "m")
    )
    private fun sym1Rows() = listOf(
        listOf("1", "2", "3", "4", "5", "6", "7", "8", "9", "0"),
        listOf("@", "#", "$", "_", "&", "-", "+", "(", ")", "/"),
        if (lastLetterPage == Page.EN) listOf(",", "\"", "'", ":", ";", "!", "?")
        else listOf(",", "\"", "'", ":", "؛", "!", "؟")
    )
    private val sym2 = listOf(
        listOf("~", "`", "|", "•", "√", "π", "÷", "×", "§", "Δ"),
        listOf("£", "€", "¥", "﷼", "^", "°", "=", "{", "}", "\\"),
        listOf("%", "©", "®", "™", "✓", "[", "]")
    )

    // ---------- بدائل الضغطة الطويلة ----------
    private val arAlts = mapOf(
        "ق" to listOf("ڨ"),
        "ف" to listOf("ڤ", "ڢ", "ڥ"),
        "ه" to listOf("ه\u200D"),
        "ج" to listOf("چ"),
        "ش" to listOf("ڜ"),
        "ي" to listOf("ئ"),
        "ب" to listOf("پ"),
        "ل" to listOf("لا", "لأ", "لإ", "لآ"),
        "ا" to listOf("أ", "إ", "ء", "ٱ", "آ"),
        "ك" to listOf("گ", "ک", "ڭ"),
        "ى" to listOf("ئ"),
        "و" to listOf("ؤ"),
        "ز" to listOf("ژ")
    )
    // الإنجليزي: قوائم AOSP أولاً ثم بعض الإضافات
    private val enAlts = mapOf(
        "a" to listOf("à", "á", "â", "ä", "æ", "ã", "å", "ā"),
        "o" to listOf("ó", "ô", "ö", "ò", "œ", "ø", "ō", "õ"),
        "e" to listOf("é", "è", "ê", "ë", "ē"),
        "u" to listOf("ú", "û", "ü", "ù", "ū"),
        "i" to listOf("í", "î", "ï", "ī", "ì"),
        "n" to listOf("ñ", "ń"),
        "c" to listOf("ç", "ć", "č"),
        "s" to listOf("ß", "ś", "š", "ş"),
        "y" to listOf("ý", "ÿ"),
        "z" to listOf("ž", "ź", "ż"),
        "l" to listOf("ł"),
        "d" to listOf("ð"),
        "g" to listOf("ğ"),
        "t" to listOf("þ")
    )
    // بدائل صفحة الرموز بالعربي كما تظهر في Gboard (الترتيب: الأول عند المفتاح ثم يمين/يسار بالتناوب)
    private val arSymAlts = mapOf(
        "1" to listOf("١", "1", "½", "⅓", "¼", "⅕", "⅙", "⅐"),
        "2" to listOf("٢", "2", "⅔", "⅖"),
        "3" to listOf("٣", "3", "¾", "⅗", "⅜"),
        "4" to listOf("٤", "4", "⅘"),
        "5" to listOf("٥", "5", "⅚", "⅝"),
        "6" to listOf("٦", "6"),
        "7" to listOf("٧", "7", "⅞"),
        "8" to listOf("٨", "8"),
        "9" to listOf("٩", "9"),
        "0" to listOf("٠", "0", "ⁿ", "∅"),
        "#" to listOf("№"),
        "$" to listOf("¢", "£", "€", "¥", "₱", "₹"),
        "﷼" to listOf("$", "¢", "€", "£", "¥", "₱", "₹"),
        "-" to listOf("_", "–", "—", "·"),
        "+" to listOf("±"),
        "(" to listOf("\uFD3E", "<", "{", "["),
        ")" to listOf("\uFD3F", ">", "}", "]"),
        "،" to listOf("،", "'", "\"", "*"),
        "\"" to listOf("”", "«", "“", "»", "„"),
        "'" to listOf("’", "‹", "‘", "›", "‚"),
        "؛" to listOf(";"),
        "!" to listOf("¡"),
        "؟" to listOf("?", "¿"),
        "." to listOf("…"),
        "%" to listOf("‰", "%", "٪"),
        "§" to listOf("¶"),
        "=" to listOf("≠", "≈", "∞"),
        "π" to listOf("Π", "µ", "Ω"),
        "•" to listOf("♪", "♥", "♠", "♦", "♣"),
        "°" to listOf("′", "″"),
        "^" to listOf("↑", "↓", "←", "→"),
        "«" to listOf("‹", "≤", "<", "⟨"),
        "»" to listOf("›", "≥", ">", "⟩")
    )
    private fun symAltsFor(ch: String): List<String> =
        (if (lastLetterPage == Page.AR) arSymAlts[ch] else null) ?: symAlts[ch].orEmpty()

    private val indicDigits = "٠١٢٣٤٥٦٧٨٩"
    private val symAlts = mapOf(
        "1" to listOf("١", "¹", "½", "⅓", "¼", "⅕", "⅙", "⅐"),
        "2" to listOf("٢", "²", "⅔", "⅖"),
        "3" to listOf("٣", "³", "¾", "⅗", "⅜"),
        "4" to listOf("٤", "⁴", "⅘"),
        "5" to listOf("⅝"),
        "7" to listOf("⅞"),
        "0" to listOf("ⁿ", "∅"),
        "-" to listOf("_", "–", "—", "·"),
        "+" to listOf("±"),
        "$" to listOf("¢", "£", "€", "¥", "₱", "₹"),
        "#" to listOf("№"),
        "§" to listOf("¶"),
        "(" to listOf("<", "{", "["),
        ")" to listOf(">", "}", "]"),
        "*" to listOf("†", "‡", "★"),
        "\"" to listOf("“", "”", "„", "«", "»"),
        "'" to listOf("‘", "’", "‚", "‹", "›"),
        "!" to listOf("¡"),
        "?" to listOf("¿"),
        "؟" to listOf("?", "¿"),
        "؛" to listOf(";"),
        "%" to listOf("‰"),
        "•" to listOf("♪", "♥", "♠", "♦", "♣"),
        "=" to listOf("≠", "≈", "∞"),
        "<" to listOf("≤", "‹", "«"),
        ">" to listOf("≥", "›", "»"),
        "," to listOf("،"),
        "." to listOf("…")
    )
    // نافذة الحركات (تظهر بالضغط الطويل على زر ◌ مثل Gboard): صفّان، والمحدد افتراضياً ؟
    private val harakatGrid = listOf(
        "\u0656", "\u0670", "\u0653", "\u0650", "\u064F", "\u0640", "\u0655", "\u0654",
        "\u064E", "\u0652", "\u064D", "\u064C", "\u0651", "\u064B", "؟", "!"
    )
    private val dotAr = listOf("،", "؟", "!", ":", "؛", "…", "\"", "-")
    private val dotEn = listOf(",", "?", "!", "#", ")", "(", "/", ";", "'", "@", ":", "-", "\"", "+", "%", "&")

    private fun dotAlts() = if (lastLetterPage == Page.EN) dotEn else dotAr

    private fun altsFor(ch: String, hint: String?): List<String> {
        val base = (if (page == Page.EN) enAlts else arAlts)[ch].orEmpty()
        val shifted = if (page == Page.EN && (shift || caps)) base.map { it.uppercase() } else base
        val digits = if (hint == null) emptyList()
                     else listOf(hint)
        return digits + shifted
    }

    private fun showPicker() {
        (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).showInputMethodPicker()
    }

    private fun symKey(ch: String, color: Int = cKey, pressed: Int = cKeyDown) =
        key(ch, 1f, color, pressed, preview = true, alts = { symAltsFor(ch) }) { typeText(ch) }

    private val cKey get() = Theme.current.key
    private val cKeyDown get() = Theme.current.keyDown
    private val cSpecial get() = Theme.current.special
    private val cSpecialDown get() = Theme.current.specialDown
    private val cAction get() = Theme.current.action
    private val cActionDown get() = Theme.current.actionDown

    override fun onCreateInputView(): View {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_LTR
            setPadding(dp(3), dp(2), dp(3), dp(6))
        }
        applyPrefs(rebuild = false)

        // أزرار الأدوات: رمز فقط، والضغطة الطويلة تعرض اسم الأداة
        modeButton = toolButton(modeIcon(mode), 0xFF00897B.toInt(), { "الوضع: ${mode.label}  (اضغط للتغيير)" }) {
            playSound(0); nextMode()
        }
        micButton = toolButton("🎤", 0xFF4A5C94.toInt(), {
            if (listening) "إيقاف الإدخال الصوتي" else "إدخال صوتي"
        }) { playSound(3); toggleVoice() }
        toolsRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_LTR
            gravity = android.view.Gravity.CENTER_VERTICAL
            addView(modeButton, toolParams())
            addView(micButton, toolParams())
            addView(toolButton("🌍", 0xFF6A4C93.toInt(), { "ترجمة (عربي ⇄ إنجليزي)" }) {
                playSound(3); startTranslate()
            }, toolParams())
            addView(toolButton("✨", 0xFFAD1457.toInt(), { "زخرفة الحروف" }) {
                playSound(3); openDecor()
            }, toolParams())
            addView(toolButton("📋", 0xFF2E7D6B.toInt(), { "الحافظة" }) {
                playSound(3); captureClip(); setPage(Page.CLIP)
            }, toolParams())
            addView(toolButton("🔄", 0xFF4A5C94.toInt(), { "فك العكس: يلصق النص المنسوخ بعد فك عكسه" }) {
                playSound(3); pasteUnreversed()
            }, toolParams())
            addView(toolButton("↔️", 0xFF546E7A.toInt(), { "وضع اليد الواحدة (يمين / يسار / إيقاف)" }) {
                playSound(3); cycleOneHand()
            }, toolParams())
            addView(toolButton("🔡", 0xFFB26A00.toInt(), { "فك الإنجليزي: يحوّل العربي المكتوب بحروف إنجليزية إلى عربي" }) {
                playSound(3); pasteDecodedArabizi()
            }, toolParams())
        }
        toolsScroll = android.widget.HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            isFillViewport = true
            layoutDirection = View.LAYOUT_DIRECTION_LTR
            addView(toolsRow, android.widget.FrameLayout.LayoutParams(
                android.widget.FrameLayout.LayoutParams.MATCH_PARENT,
                android.widget.FrameLayout.LayoutParams.WRAP_CONTENT))
        }
        root.addView(toolsScroll)
        root.addView(buildSuggestRow())
        root.addView(buildHarakatRow())
        root.addView(buildTransRow())
        root.addView(buildEmojiSearchRow())

        keysBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(keysBox)
        buildPage()

        // طبقة شفافة فوق الكيبورد لعرض الفقاعات وقوائم البدائل داخل نافذة الكيبورد نفسها
        overlay = android.widget.FrameLayout(this).apply {
            clipChildren = false
            layoutDirection = View.LAYOUT_DIRECTION_LTR
        }
        return android.widget.FrameLayout(this).apply {
            clipChildren = false
            layoutDirection = View.LAYOUT_DIRECTION_LTR
            addView(root, android.widget.FrameLayout.LayoutParams(
                android.widget.FrameLayout.LayoutParams.MATCH_PARENT,
                android.widget.FrameLayout.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(POPUP_AREA) })
            addView(this@KeyboardService.overlay, android.widget.FrameLayout.LayoutParams(
                android.widget.FrameLayout.LayoutParams.MATCH_PARENT,
                android.widget.FrameLayout.LayoutParams.MATCH_PARENT))
        }
    }

    // المنطقة الشفافة فوق الكيبورد ما تاخذ اللمس (تمرّره للتطبيق)
    override fun onComputeInsets(outInsets: Insets) {
        super.onComputeInsets(outInsets)
        if (!isFullscreenMode && ::root.isInitialized) {
            val top = dp(POPUP_AREA)
            outInsets.contentTopInsets += top
            outInsets.visibleTopInsets += top
            outInsets.touchableInsets = Insets.TOUCHABLE_INSETS_VISIBLE
        }
    }

    // ---------- الترجمة ----------
    private fun buildTransRow(): LinearLayout {
        transRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_LTR
            gravity = android.view.Gravity.CENTER_VERTICAL
            visibility = View.GONE
        }
        transText = android.widget.TextView(this).apply {
            gravity = android.view.Gravity.CENTER
            textSize = 16f
            maxLines = 1
            ellipsize = android.text.TextUtils.TruncateAt.END
            setTextColor(0xFFFFFFFF.toInt())
            background = android.graphics.drawable.GradientDrawable().apply {
                setColor(0xFF3B3F4F.toInt()); cornerRadius = dp(8).toFloat()
            }
            setPadding(dp(10), 0, dp(10), 0)
            setOnClickListener { applyTranslation() }
        }
        transRow.addView(transText, LinearLayout.LayoutParams(0, dp(34), 1f).apply { setMargins(dp(4), dp(1), dp(4), dp(1)) })
        transRow.addView(android.widget.TextView(this).apply {
            text = "✕"
            textSize = 18f
            gravity = android.view.Gravity.CENTER
            setTextColor(0xFFFFFFFF.toInt())
            setOnClickListener { showTrans = false; transToken++; updateSuggestions() }
        }, LinearLayout.LayoutParams(dp(40), dp(34)))
        return transRow
    }

    private fun startTranslate() {
        val ic = currentInputConnection ?: return
        val selected = ic.getSelectedText(0)?.toString().orEmpty()
        val before = ic.getTextBeforeCursor(2000, 0)?.toString().orEmpty()
        val after = ic.getTextAfterCursor(2000, 0)?.toString().orEmpty()
        val text = if (selected.isNotEmpty()) selected else before + after
        if (text.isBlank()) { toast("اكتب شي أول عشان أترجمه"); return }
        commit()
        transSelected = selected.isNotEmpty()
        transBeforeLen = before.length
        transAfterLen = after.length

        val ar = text.count { it in '\u0600'..'\u06FF' }
        val la = text.count { it in 'A'..'Z' || it in 'a'..'z' }
        val toEn = ar >= la
        val src = if (toEn) TranslateLanguage.ARABIC else TranslateLanguage.ENGLISH
        val dst = if (toEn) TranslateLanguage.ENGLISH else TranslateLanguage.ARABIC

        val token = ++transToken
        showHarakat = false
        showTrans = true
        transResult = null
        transText.text = "جاري الترجمة…"
        updateSuggestions()

        val key = prefs.getString("claude_key", "").orEmpty().trim()
        transText.text = "جاري الترجمة…"
        Thread {
            var r: String? = null
            if (key.isNotEmpty()) r = try { OnlineTranslate.claude(key, text, toEn) } catch (_: Exception) { null }
            if (r == null) r = try { OnlineTranslate.google(text, toEn) } catch (_: Exception) { null }
            uiHandler.post {
                if (token != transToken || !showTrans) return@post
                if (r != null) {
                    transResult = r
                    transText.text = r
                } else {
                    // ما فيه إنترنت: نرجع للترجمة المحلية (أقل دقة)
                    transText.text = "ما فيه إنترنت — أستخدم الترجمة المحلية…"
                    mlKitTranslate(text, src, dst, token)
                }
            }
        }.start()
    }

    private fun mlKitTranslate(text: String, src: String, dst: String, token: Int) {
        val tr = translators.getOrPut("$src-$dst") {
            Translation.getClient(
                TranslatorOptions.Builder().setSourceLanguage(src).setTargetLanguage(dst).build()
            )
        }
        tr.downloadModelIfNeeded(DownloadConditions.Builder().build())
            .addOnSuccessListener {
                tr.translate(text)
                    .addOnSuccessListener { r ->
                        if (token == transToken && showTrans) { transResult = r; transText.text = r }
                    }
                    .addOnFailureListener { if (token == transToken) failTranslate("تعذّرت الترجمة") }
            }
            .addOnFailureListener { if (token == transToken) failTranslate("تعذّرت الترجمة، تأكد من الإنترنت") }
    }

    private fun failTranslate(msg: String) {
        showTrans = false
        toast(msg)
        updateSuggestions()
    }

    private fun applyTranslation() {
        val r = transResult ?: return
        val ic = currentInputConnection ?: return
        ic.beginBatchEdit()
        if (!transSelected) ic.deleteSurroundingText(transBeforeLen, transAfterLen)
        ic.commitText(r, 1)
        ic.endBatchEdit()
        showTrans = false
        transToken++
        playSound(0)
        postUpdate()
    }

    private fun buildHarakatRow(): LinearLayout {
        harakatRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_LTR
            visibility = View.GONE
        }
        val punct = listOf(".", "!", "؟", "،")
        (harakat + punct).forEach { h ->
            val isPunct = h in punct
            harakatRow.addView(android.widget.TextView(this).apply {
                text = if (isPunct) h else "\u25CC$h"
                gravity = android.view.Gravity.CENTER
                textSize = 20f
                setTextColor(0xFFFFFFFF.toInt())
                background = android.graphics.drawable.GradientDrawable().apply {
                    setColor(0xFF3B3F4F.toInt()); cornerRadius = dp(8).toFloat()
                }
                layoutParams = LinearLayout.LayoutParams(0, dp(36), 1f).apply { setMargins(dp(2), dp(1), dp(2), dp(1)) }
                setOnClickListener {
                    performHapticFeedback(android.view.HapticFeedbackConstants.KEYBOARD_TAP)
                    playSound(0)
                    typeText(h)
                    if (isPunct) { showHarakat = false; updateSuggestions() }
                }
            })
        }
        return harakatRow
    }

    private fun toggleHarakat() {
        showTrans = false
        showHarakat = !showHarakat
        updateSuggestions()
    }

    private fun buildSuggestRow(): LinearLayout {
        sugViews.clear()
        sugRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_LTR
            visibility = View.GONE
        }
        for (i in 0 until 3) {
            if (i > 0) sugRow.addView(View(this).apply {
                setBackgroundColor(0x33FFFFFF)
                layoutParams = LinearLayout.LayoutParams(dp(1), dp(20)).apply { gravity = android.view.Gravity.CENTER_VERTICAL }
            })
            val tv = android.widget.TextView(this).apply {
                gravity = android.view.Gravity.CENTER
                textSize = 17f
                maxLines = 1
                setTextColor(0xFFFFFFFF.toInt())
                layoutParams = LinearLayout.LayoutParams(0, dp(36), 1f)
                setOnClickListener { applySuggestion(i) }
            }
            sugViews.add(tv)
            sugRow.addView(tv)
        }
        return sugRow
    }

    // ---------- شريط الأدوات ----------
    private fun modeIcon(m: Mode) = when (m) {
        Mode.NORMAL -> "✏️"
        Mode.ARABIZI -> "🅰️"
        Mode.REVERSE -> "🔁"
        Mode.NODOTS -> "⚪"
        Mode.BOTH -> "🔀"
    }

    private fun toolParams() = LinearLayout.LayoutParams(0, dp(30), 1f).apply {
        setMargins(dp(3), dp(3), dp(3), dp(3))
    }

    private fun toolButton(icon: String, color: Int, label: () -> String, onClick: () -> Unit): android.widget.TextView =
        android.widget.TextView(this).apply {
            text = icon
            textSize = 17f
            gravity = android.view.Gravity.CENTER
            setTextColor(0xFFFFFFFF.toInt())
            background = android.graphics.drawable.GradientDrawable().apply {
                setColor(color); cornerRadius = dp(10).toFloat()
            }
            isClickable = true
            setOnClickListener { onClick() }
            setOnLongClickListener {
                performHapticFeedback(android.view.HapticFeedbackConstants.LONG_PRESS)
                showTip(this, label())
                true
            }
        }

    private var tipView: View? = null
    private val tipRunnable = Runnable { removeTip() }

    private fun removeTip() {
        tipView?.let { (it.parent as? android.view.ViewGroup)?.removeView(it) }
        tipView = null
    }

    /** يعرض اسم الأداة فوقها (داخل نافذة الكيبورد). */
    private fun showTip(anchor: View, msg: String) {
        if (!::overlay.isInitialized) return
        removeTip()
        uiHandler.removeCallbacks(tipRunnable)
        val tv = android.widget.TextView(this).apply {
            text = msg
            textSize = 14f
            maxWidth = resources.displayMetrics.widthPixels - dp(24)
            setTextColor(0xFFFFFFFF.toInt())
            setPadding(dp(12), dp(8), dp(12), dp(8))
            background = android.graphics.drawable.GradientDrawable().apply {
                setColor(0xFF5A6078.toInt()); cornerRadius = dp(10).toFloat()
            }
        }
        tv.measure(
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED),
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
        )
        val w = tv.measuredWidth
        val h = tv.measuredHeight
        val al = IntArray(2); anchor.getLocationInWindow(al)
        val ol = IntArray(2); overlay.getLocationInWindow(ol)
        val x = (al[0] - ol[0] + anchor.width / 2 - w / 2).coerceIn(0, maxOf(0, overlay.width - w))
        val y = maxOf(0, al[1] - ol[1] - h - dp(4))
        overlay.addView(tv, android.widget.FrameLayout.LayoutParams(
            android.widget.FrameLayout.LayoutParams.WRAP_CONTENT,
            android.widget.FrameLayout.LayoutParams.WRAP_CONTENT
        ).apply {
            gravity = android.view.Gravity.TOP or android.view.Gravity.LEFT
            leftMargin = x
            topMargin = y
        })
        tipView = tv
        uiHandler.postDelayed(tipRunnable, 1800)
    }

    // ---------- الإدخال الصوتي ----------
    private fun toast(msg: String) =
        android.widget.Toast.makeText(this, msg, android.widget.Toast.LENGTH_SHORT).show()

    private fun setMicState(on: Boolean) {
        listening = on
        micButton.text = if (on) "🔴" else "🎤"
        (micButton.background as? android.graphics.drawable.GradientDrawable)
            ?.setColor(if (on) 0xFFC62828.toInt() else 0xFF4A5C94.toInt())
        postUpdate()
    }

    private fun toggleVoice() {
        if (listening) {
            recognizer?.stopListening()
            return
        }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            startActivity(Intent(this, PermissionActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            toast("اسمح بالميكروفون ثم اضغط 🎤 مرة ثانية")
            return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            toast("خدمة التعرف على الصوت غير متوفرة في جوالك")
            return
        }
        commit()
        val r = SpeechRecognizer.createSpeechRecognizer(this)
        recognizer = r
        r.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: android.os.Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onEvent(eventType: Int, params: android.os.Bundle?) {}

            override fun onPartialResults(partial: android.os.Bundle?) {
                if (mode != Mode.NORMAL) return
                val t = partial?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                if (!t.isNullOrEmpty()) currentInputConnection?.setComposingText(spaced(t), 1)
            }

            override fun onResults(results: android.os.Bundle?) {
                val t = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                if (!t.isNullOrEmpty()) {
                    if (mode == Mode.NORMAL) {
                        currentInputConnection?.commitText(spaced(t) + " ", 1)
                    } else {
                        buffer.append(t).append(' ')
                        render()
                    }
                } else {
                    currentInputConnection?.finishComposingText()
                }
                stopVoice()
            }

            override fun onError(error: Int) {
                currentInputConnection?.finishComposingText()
                when (error) {
                    SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> toast("ما سمعت شي")
                    SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> toast("اسمح بالميكروفون من إعدادات التطبيق")
                    SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> toast("تأكد من الإنترنت")
                    else -> toast("تعذّر الإدخال الصوتي")
                }
                stopVoice()
            }
        })
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, if (lastLetterPage == Page.EN) "en-US" else "ar-SA")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
        }
        val before = currentInputConnection?.getTextBeforeCursor(1, 0)?.toString().orEmpty()
        dictPrefix = if (before.isNotEmpty() && !before[0].isWhitespace()) " " else ""
        setMicState(true)
        r.startListening(intent)
    }

    /** يضيف مسافة قبل النص المملى إذا قبله كلام. */
    private var dictPrefix = ""

    private fun spaced(t: String) = dictPrefix + t

    private fun stopVoice() {
        try { recognizer?.destroy() } catch (_: Exception) {}
        recognizer = null
        if (::micButton.isInitialized) setMicState(false)
    }

    // ---------- الاقتراحات ----------
    private fun isWordChar(c: Char) =
        Character.isLetter(c) || Character.getType(c) == Character.NON_SPACING_MARK.toInt()

    private fun currentWord(): String {
        val before = currentInputConnection?.getTextBeforeCursor(32, 0)?.toString().orEmpty()
        var i = before.length
        while (i > 0 && isWordChar(before[i - 1])) i--
        return before.substring(i)
    }

    private fun postUpdate() {
        uiHandler.removeCallbacks(updateRunnable)
        uiHandler.postDelayed(updateRunnable, 20)
    }

    private fun updateSuggestions() {
        if (!::sugRow.isInitialized) return
        if (::emojiSearchRow.isInitialized) {
            emojiSearchRow.visibility = if (emojiSearch) View.VISIBLE else View.GONE
            if (emojiSearch) {
                transRow.visibility = View.GONE
                harakatRow.visibility = View.GONE
                sugRow.visibility = View.GONE
                toolsScroll.visibility = View.GONE
                return
            }
        }
        val active = suggestOk && !listening && mode == Mode.NORMAL
        val word = if (active) currentWord() else ""
        val ga = glideAlt
        val list = when {
            !active -> emptyList()
            ga != null && word.isEmpty() -> ga
            word.isNotEmpty() -> suggestions.suggest(word)
            else -> {
                val before = currentInputConnection?.getTextBeforeCursor(40, 0)?.toString().orEmpty()
                val m = Regex("(\\p{L}+) $").find(before)
                if (m != null) suggestions.predictNext(m.groupValues[1]) else emptyList()
            }
        }
        currentSug = list
        currentWordLen = word.length
        transRow.visibility = if (showTrans) View.VISIBLE else View.GONE
        if (showTrans) {
            harakatRow.visibility = View.GONE
            sugRow.visibility = View.GONE
            toolsScroll.visibility = View.GONE
            return
        }
        harakatRow.visibility = if (showHarakat) View.VISIBLE else View.GONE
        if (showHarakat) {
            sugRow.visibility = View.GONE
            toolsScroll.visibility = View.GONE
            return
        }
        if (list.isEmpty()) {
            sugRow.visibility = View.GONE
            toolsScroll.visibility = View.VISIBLE
        } else {
            toolsScroll.visibility = View.GONE
            sugRow.visibility = View.VISIBLE
            sugViews.forEachIndexed { i, tv ->
                tv.text = list.getOrNull(i) ?: ""
                tv.isEnabled = i < list.size
            }
        }
    }

    /** يتعلّم زوج الكلمات (السابقة ← الحالية) عشان يقترح الكلمة التالية. */
    private fun learnPairBefore(trailingSpace: Boolean) {
        val before = currentInputConnection?.getTextBeforeCursor(64, 0)?.toString() ?: return
        val re = if (trailingSpace) Regex("(\\p{L}+)\\s+(\\p{L}+)\\s$") else Regex("(\\p{L}+)\\s+(\\p{L}+)$")
        re.find(before)?.let { suggestions.learnPair(it.groupValues[1], it.groupValues[2]) }
    }

    private fun applySuggestion(i: Int) {
        val w = currentSug.getOrNull(i) ?: return
        val ic = currentInputConnection ?: return
        val g = glideAlt != null && currentWordLen == 0
        val delLen = if (g) glideLen else currentWordLen
        glideAlt = null
        autoUndo = null
        ic.beginBatchEdit()
        ic.deleteSurroundingText(delLen, 0)
        ic.commitText("$w ", 1)
        ic.endBatchEdit()
        suggestions.learn(w)
        learnPairBefore(true)
        playSound(0)
        postUpdate()
    }

    override fun onUpdateSelection(
        oldSelStart: Int, oldSelEnd: Int, newSelStart: Int, newSelEnd: Int,
        candidatesStart: Int, candidatesEnd: Int
    ) {
        super.onUpdateSelection(oldSelStart, oldSelEnd, newSelStart, newSelEnd, candidatesStart, candidatesEnd)
        // إذا حرّك المستخدم المؤشر (أو حدّد نص) خارج نهاية النص المؤقت: نثبّت النص ونفرّغ المخزن،
        // عشان المسح والكتابة يشتغلون عند المؤشر مو من آخر النص.
        if (buffer.isNotEmpty() && candidatesStart >= 0 &&
            (newSelStart != candidatesEnd || newSelEnd != candidatesEnd)) {
            currentInputConnection?.finishComposingText()
            buffer.clear()
        }
        postUpdate()
    }

    // ---------- التفضيلات: الثيم، الحجم، اليد الواحدة ----------
    private var keyScale = 1f
    private fun keyH() = (resources.displayMetrics.density * 52 * keyScale).toInt()

    private fun applyPrefs(rebuild: Boolean) {
        Theme.set(prefs.getString("theme", "blue"))
        keyScale = prefs.getInt("kb_scale", 100).coerceIn(70, 140) / 100f
        if (!::root.isInitialized) return
        val t = Theme.current
        root.background = android.graphics.drawable.GradientDrawable(
            android.graphics.drawable.GradientDrawable.Orientation.TOP_BOTTOM,
            intArrayOf(t.bgTop, t.bgBottom)
        )
        val hand = prefs.getString("onehand", "off")
        val lp = root.layoutParams as? android.widget.FrameLayout.LayoutParams
        if (lp != null) {
            val full = android.widget.FrameLayout.LayoutParams.MATCH_PARENT
            lp.width = if (hand == "off") full else (resources.displayMetrics.widthPixels * 0.82f).toInt()
            lp.gravity = when (hand) {
                "left" -> android.view.Gravity.TOP or android.view.Gravity.LEFT
                "right" -> android.view.Gravity.TOP or android.view.Gravity.RIGHT
                else -> android.view.Gravity.TOP
            }
            root.layoutParams = lp
        }
        if (rebuild && ::keysBox.isInitialized) buildPage()
    }

    private fun cycleOneHand() {
        val next = when (prefs.getString("onehand", "off")) { "off" -> "right"; "right" -> "left"; else -> "off" }
        prefs.edit().putString("onehand", next).apply()
        toast(when (next) { "right" -> "وضع اليد الواحدة: يمين"; "left" -> "وضع اليد الواحدة: يسار"; else -> "وضع اليد الواحدة: إيقاف" })
        applyPrefs(rebuild = true)
    }

    private fun buildPage() {
        keysBox.removeAllViews()
        letterKeys.clear()
        shiftKey = null
        when (page) {
            Page.AR -> buildLetters(arRows, "العربية")
            Page.EN -> buildLetters(enRows, "English")
            Page.SYM1 -> buildSymbols(sym1Rows(), "=\\<", Page.SYM2)
            Page.NUM -> buildNumpad()
            Page.SYM2 -> buildSymbols(sym2, "?123", Page.SYM1)
            Page.EMOJI -> buildEmoji()
            Page.CLIP -> buildClipboard()
            Page.DECOR -> buildDecor()
        }
    }

    private fun buildLetters(rows: List<List<String>>, spaceLabel: String) {
        val isEn = page == Page.EN
        val digits = "1234567890"
        // الصف الأول
        keysBox.addView(row().apply {
            rows[0].forEachIndexed { i, ch -> addView(letter(ch, digits.getOrNull(i)?.toString())) }
        })
        // الصف الثاني
        keysBox.addView(row().apply {
            if (isEn) addView(spacer(0.5f))
            rows[1].forEach { ch -> addView(letter(ch, null)) }
            if (isEn) addView(spacer(0.5f))
        })
        // الصف الثالث
        keysBox.addView(row().apply {
            if (isEn) {
                shiftKey = key(if (caps) "⇪" else "⇧", 1.5f, cSpecial, cSpecialDown) { onShift() }
                addView(shiftKey)
            }
            rows[2].forEach { ch -> addView(letter(ch, null)) }
            addView(backspaceKey())
        })
        // الصف الأخير
        keysBox.addView(row().apply {
            addView(key("?123", 1.5f, cSpecial, cSpecialDown) { setPage(Page.SYM1) })
            val comma = if (isEn) "," else "،"
            addView(key("😊", 1f, cSpecial, cSpecialDown, hint = comma, size = 18f,
                onLong = { typeText(comma) }) { setPage(Page.EMOJI) })
            addView(key("🌐", 1f, cSpecial, cSpecialDown, onLong = { showPicker() }) { switchLanguage() })
            addView(key(spaceLabel, 4f, cKey, cKeyDown, snd = 1, size = 14f, onLong = { showPicker() }, slide = true) { typeText(" ") })
            if (isEn) {
                addView(key(".", 1f, cSpecial, cSpecialDown, preview = true, alts = { dotAlts() }, altCols = 8) { typeText(".") })
            } else {
                addView(key("\u25CC\u0651", 1f, cSpecial, cSpecialDown, size = 20f,
                    alts = { harakatGrid }, altCols = 8, altDefault = 14) { toggleHarakat() })
            }
            addView(enterKey())
        })
        refreshShift()
    }

    // ---------- الزخرفة ----------
    private var decorSrc = ""
    private var decorSample = false
    private var decorSelected = false
    private var decorBefore = 0
    private var decorAfter = 0

    private fun openDecor() {
        val ic = currentInputConnection
        val sel = ic?.getSelectedText(0)?.toString().orEmpty()
        val before = ic?.getTextBeforeCursor(2000, 0)?.toString().orEmpty()
        val after = ic?.getTextAfterCursor(2000, 0)?.toString().orEmpty()
        commit()
        decorSelected = sel.isNotEmpty()
        decorBefore = before.length
        decorAfter = after.length
        val text = if (decorSelected) sel else before + after
        decorSample = text.isBlank()
        decorSrc = if (decorSample) "مرحبا Hello" else text
        setPage(Page.DECOR)
    }

    private fun applyDecor(style: (String) -> String) {
        val ic = currentInputConnection ?: return
        val result = style(decorSrc)
        ic.beginBatchEdit()
        if (!decorSelected && !decorSample) ic.deleteSurroundingText(decorBefore, decorAfter)
        ic.commitText(result, 1)
        ic.endBatchEdit()
        playSound(0)
        setPage(lastLetterPage)
        postUpdate()
    }

    private fun buildDecor() {
        keysBox.addView(android.widget.TextView(this).apply {
            text = if (decorSample) "اكتب نص أول وارجع هنا — هذا مثال  •  اضغط على الشكل اللي تبيه"
                   else "اضغط على الشكل اللي تبيه وينكتب مكان النصك"
            textSize = 12f
            setTextColor(0xB3FFFFFF.toInt())
            gravity = android.view.Gravity.CENTER
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(36))
        })
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        Decor.styles.forEach { (name, fn) ->
            val preview = try { fn(decorSrc) } catch (_: Exception) { decorSrc }
            list.addView(LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                layoutDirection = View.LAYOUT_DIRECTION_LTR
                setPadding(dp(10), dp(6), dp(10), dp(6))
                background = android.graphics.drawable.GradientDrawable().apply {
                    setColor(0xFF3B3F4F.toInt()); cornerRadius = dp(8).toFloat()
                }
                addView(android.widget.TextView(this@KeyboardService).apply {
                    text = name
                    textSize = 11f
                    setTextColor(0x99FFFFFF.toInt())
                })
                addView(android.widget.TextView(this@KeyboardService).apply {
                    text = preview
                    textSize = 17f
                    maxLines = 2
                    ellipsize = android.text.TextUtils.TruncateAt.END
                    setTextColor(0xFFFFFFFF.toInt())
                })
                setOnClickListener { applyDecor(fn) }
            }, LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { setMargins(dp(4), dp(3), dp(4), dp(3)) })
        }
        keysBox.addView(android.widget.ScrollView(this).apply {
            isVerticalScrollBarEnabled = false
            addView(list)
        }, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(170)))
        keysBox.addView(row().apply {
            addView(key(if (lastLetterPage == Page.EN) "ABC" else "أبج", 1.5f, cSpecial, cSpecialDown, size = 14f) {
                setPage(lastLetterPage)
            })
            addView(key("␣", 5f, cKey, cKeyDown, snd = 1) { typeText(" ") })
            addView(backspaceKey())
            addView(enterKey())
        })
    }

    // ---------- الحافظة ----------
    private fun loadClips(): MutableList<Pair<String, Boolean>> = try {
        val arr = org.json.JSONArray(prefs.getString("clips", "[]"))
        (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            o.getString("t") to o.optBoolean("p")
        }.toMutableList()
    } catch (_: Exception) {
        mutableListOf()
    }

    private fun saveClips(list: List<Pair<String, Boolean>>) {
        val arr = org.json.JSONArray()
        list.forEach { arr.put(org.json.JSONObject().put("t", it.first).put("p", it.second)) }
        prefs.edit().putString("clips", arr.toString()).apply()
    }

    private fun captureClip() {
        if (!prefs.getBoolean("clip_history", true)) return
        try {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
            val clip = cm.primaryClip ?: return
            if (clip.itemCount == 0) return
            if (android.os.Build.VERSION.SDK_INT >= 33 &&
                clip.description?.extras?.getBoolean("android.content.extra.IS_SENSITIVE") == true) return
            val t = clip.getItemAt(0).coerceToText(this)?.toString()?.trim().orEmpty()
            if (t.isEmpty() || t.length > 5000) return
            if (t == prefs.getString("clip_last", "")) return
            prefs.edit().putString("clip_last", t).apply()
            val list = loadClips()
            val pinned = list.firstOrNull { it.first == t }?.second ?: false
            list.removeAll { it.first == t }
            list.add(0, t to pinned)
            var n = 0
            saveClips(list.filter { it.second || ++n <= 30 })
        } catch (_: Exception) {
        }
    }

    private fun buildClipboard() {
        val all = loadClips()
        val items = all.filter { it.second } + all.filter { !it.second }

        keysBox.addView(android.widget.TextView(this).apply {
            text = "الحافظة  •  اضغط للصق  •  ضغطة طويلة للتثبيت 📌"
            textSize = 13f
            setTextColor(0xB3FFFFFF.toInt())
            gravity = android.view.Gravity.CENTER
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(36))
        })

        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        if (items.isEmpty()) {
            list.addView(android.widget.TextView(this).apply {
                text = "انسخ أي نص وبيطلع هنا"
                setTextColor(0x99FFFFFF.toInt())
                gravity = android.view.Gravity.CENTER
                setPadding(0, dp(40), 0, 0)
            })
        }
        items.forEach { (t, pinned) ->
            list.addView(LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                layoutDirection = View.LAYOUT_DIRECTION_LTR
                gravity = android.view.Gravity.CENTER_VERTICAL
                addView(android.widget.TextView(this@KeyboardService).apply {
                    text = if (pinned) "📌 $t" else t
                    textSize = 15f
                    maxLines = 2
                    ellipsize = android.text.TextUtils.TruncateAt.END
                    setTextColor(0xFFFFFFFF.toInt())
                    setPadding(dp(10), dp(6), dp(10), dp(6))
                    background = android.graphics.drawable.GradientDrawable().apply {
                        setColor(if (pinned) 0xFF2C3350.toInt() else 0xFF3B3F4F.toInt())
                        cornerRadius = dp(8).toFloat()
                    }
                    setOnClickListener {
                        commit()
                        currentInputConnection?.commitText(t, 1)
                        playSound(0)
                        postUpdate()
                    }
                    setOnLongClickListener {
                        val cur = loadClips()
                        val idx = cur.indexOfFirst { it.first == t }
                        if (idx >= 0) cur[idx] = t to !cur[idx].second
                        saveClips(cur)
                        buildPage()
                        true
                    }
                }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
                    setMargins(dp(4), dp(3), dp(2), dp(3))
                })
                addView(android.widget.TextView(this@KeyboardService).apply {
                    text = "✕"
                    textSize = 16f
                    gravity = android.view.Gravity.CENTER
                    setTextColor(0xB3FFFFFF.toInt())
                    setOnClickListener {
                        saveClips(loadClips().filter { it.first != t })
                        buildPage()
                    }
                }, LinearLayout.LayoutParams(dp(40), dp(40)))
            })
        }
        keysBox.addView(android.widget.ScrollView(this).apply {
            isVerticalScrollBarEnabled = false
            addView(list)
        }, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(170)))

        keysBox.addView(row().apply {
            addView(key(if (lastLetterPage == Page.EN) "ABC" else "أبج", 1.5f, cSpecial, cSpecialDown, size = 14f) {
                setPage(lastLetterPage)
            })
            addView(key("مسح الكل", 2f, cSpecial, cSpecialDown, size = 14f) {
                saveClips(loadClips().filter { it.second })
                prefs.edit().putString("clip_last", "").apply()
                buildPage()
            })
            addView(key("␣", 3f, cKey, cKeyDown, snd = 1) { typeText(" ") })
            addView(backspaceKey())
            addView(enterKey())
        })
    }


    // ---------- بحث الإيموجي + لون البشرة ----------
    private fun buildEmojiSearchRow(): LinearLayout {
        emojiQueryTv = android.widget.TextView(this).apply {
            textSize = 15f
            maxLines = 1
            ellipsize = android.text.TextUtils.TruncateAt.END
            setTextColor(0xFFFFFFFF.toInt())
            gravity = android.view.Gravity.CENTER_VERTICAL
            setPadding(dp(10), 0, dp(10), 0)
            background = android.graphics.drawable.GradientDrawable().apply {
                setColor(0xFF3B3F4F.toInt()); cornerRadius = dp(18).toFloat()
            }
            layoutParams = LinearLayout.LayoutParams(dp(120), dp(38)).apply { setMargins(dp(2), dp(2), dp(4), dp(2)) }
        }
        emojiResultsBox = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_LTR
        }
        val scroll = android.widget.HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            layoutDirection = View.LAYOUT_DIRECTION_LTR
            addView(emojiResultsBox)
            layoutParams = LinearLayout.LayoutParams(0, dp(40), 1f)
        }
        val close = android.widget.TextView(this).apply {
            text = "✕"
            textSize = 18f
            setTextColor(0xFFFFFFFF.toInt())
            gravity = android.view.Gravity.CENTER
            layoutParams = LinearLayout.LayoutParams(dp(40), dp(40))
            setOnClickListener { closeEmojiSearch() }
        }
        emojiSearchRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_LTR
            gravity = android.view.Gravity.CENTER_VERTICAL
            visibility = View.GONE
            addView(emojiQueryTv); addView(scroll); addView(close)
        }
        return emojiSearchRow
    }

    private fun openEmojiSearch() {
        emojiSearch = true
        emojiQuery.clear()
        setPage(lastLetterPage)
        refreshEmojiResults()
        postUpdate()
    }

    private fun closeEmojiSearch() {
        emojiSearch = false
        emojiQuery.clear()
        setPage(Page.EMOJI)
        postUpdate()
    }

    private fun refreshEmojiResults() {
        if (!::emojiResultsBox.isInitialized) return
        Emojis.load(this)
        val q = emojiQuery.toString()
        emojiQueryTv.text = if (q.isEmpty()) "🔍 ابحث…" else "🔍 $q"
        emojiResultsBox.removeAllViews()
        val list = if (q.isBlank()) recentEmojis().take(20) else Emojis.search(this, q)
        if (list.isEmpty() && q.isNotBlank()) {
            emojiResultsBox.addView(android.widget.TextView(this).apply {
                text = "ما فيه نتائج"
                setTextColor(0x99FFFFFF.toInt())
                gravity = android.view.Gravity.CENTER_VERTICAL
                setPadding(dp(8), 0, 0, 0)
                layoutParams = LinearLayout.LayoutParams(dp(110), dp(40))
            })
        }
        list.forEach { e ->
            emojiResultsBox.addView(android.widget.TextView(this).apply {
                text = e
                textSize = 26f
                gravity = android.view.Gravity.CENTER
                layoutParams = LinearLayout.LayoutParams(dp(44), dp(40))
                setOnClickListener {
                    performHapticFeedback(android.view.HapticFeedbackConstants.KEYBOARD_TAP)
                    onEmoji(e)
                }
            })
        }
    }

    /** نافذة اختيار لون البشرة (ضغطة طويلة على الإيموجي). */
    private fun showToneChooser(anchor: View, variants: List<String>) {
        if (!::overlay.isInitialized) return
        val ov = overlay
        val catcher = View(this)
        val pill = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_LTR
            setPadding(dp(6), dp(4), dp(6), dp(4))
            background = android.graphics.drawable.GradientDrawable().apply {
                setColor(0xFF44464F.toInt()); cornerRadius = dp(26).toFloat()
            }
        }
        fun dismiss() {
            ov.removeView(pill); ov.removeView(catcher)
        }
        catcher.setOnClickListener { dismiss() }
        variants.forEach { v ->
            pill.addView(android.widget.TextView(this).apply {
                text = v
                textSize = 26f
                gravity = android.view.Gravity.CENTER
                layoutParams = LinearLayout.LayoutParams(dp(44), dp(46))
                setOnClickListener { onEmoji(v); dismiss() }
            })
        }
        val w = variants.size * dp(44) + dp(12)
        val h = dp(54)
        val al = IntArray(2); anchor.getLocationInWindow(al)
        val ol = IntArray(2); ov.getLocationInWindow(ol)
        val x = (al[0] - ol[0] + anchor.width / 2 - w / 2).coerceIn(0, maxOf(0, ov.width - w))
        val y = maxOf(0, al[1] - ol[1] - h)
        ov.addView(catcher, android.widget.FrameLayout.LayoutParams(
            android.widget.FrameLayout.LayoutParams.MATCH_PARENT, android.widget.FrameLayout.LayoutParams.MATCH_PARENT))
        ov.addView(pill, android.widget.FrameLayout.LayoutParams(w, h).apply {
            gravity = android.view.Gravity.TOP or android.view.Gravity.LEFT
            leftMargin = x; topMargin = y
        })
    }

    // ---------- التصحيح التلقائي (اختياري) ----------
    private var pendingUndo: Array<String>? = null

    private fun tryAutoCorrect(sep: String) {
        if (mode != Mode.NORMAL) return
        val word = currentWord()
        if (word.length < 3) return
        val fixed = suggestions.correct(word) ?: return
        if (fixed == word) return
        val ic = currentInputConnection ?: return
        ic.beginBatchEdit()
        ic.deleteSurroundingText(word.length, 0)
        ic.commitText(fixed, 1)
        ic.endBatchEdit()
        pendingUndo = arrayOf(word, fixed, sep)
    }

    // ---------- تحريك المؤشر بسحب المسافة ----------
    private fun slideCursor(dir: Int) {
        if (!prefs.getBoolean("space_slide", true)) return
        commit()
        sendDownUpKeyEvents(if (dir > 0) KeyEvent.KEYCODE_DPAD_RIGHT else KeyEvent.KEYCODE_DPAD_LEFT)
    }

    // ---------- الكتابة بالسحب ----------
    private var trail: TrailView? = null
    private val glidePts = ArrayList<FloatArray>()

    private val glideHost = object : GlideHost {
        override fun glideEnabled() =
            prefs.getBoolean("glide", true) && mode == Mode.NORMAL && !emojiSearch &&
                (page == Page.AR || page == Page.EN)

        override fun glideStart(rawX: Float, rawY: Float) {
            glidePts.clear()
            glidePts.add(floatArrayOf(rawX, rawY))
            if (::overlay.isInitialized) {
                val t = TrailView(this@KeyboardService)
                overlay.addView(t, android.widget.FrameLayout.LayoutParams(
                    android.widget.FrameLayout.LayoutParams.MATCH_PARENT,
                    android.widget.FrameLayout.LayoutParams.MATCH_PARENT))
                t.add(rawX, rawY)
                trail = t
            }
        }

        override fun glideMove(rawX: Float, rawY: Float) {
            glidePts.add(floatArrayOf(rawX, rawY))
            trail?.add(rawX, rawY)
        }

        override fun glideCancel() { removeTrail(); glidePts.clear() }

        override fun glideEnd() {
            val pts = ArrayList(glidePts)
            glidePts.clear()
            removeTrail()
            finishGlide(pts)
        }
    }

    private fun removeTrail() {
        trail?.let { (it.parent as? android.view.ViewGroup)?.removeView(it) }
        trail = null
    }

    private fun finishGlide(pts: List<FloatArray>) {
        val pad = dp(3)
        val rects = letterKeys.map { (k, ch) ->
            val l = IntArray(2); k.getLocationOnScreen(l)
            Pair(ch, android.graphics.Rect(l[0] - pad, l[1] - pad, l[0] + k.width + pad, l[1] + k.height + pad))
        }
        val sb = StringBuilder()
        var last = ""
        for (pt in pts) {
            val hit = rects.firstOrNull { it.second.contains(pt[0].toInt(), pt[1].toInt()) } ?: continue
            if (hit.first != last) { sb.append(hit.first); last = hit.first }
        }
        val seq = sb.toString()
        if (seq.length < 2) return
        val cands = suggestions.glide(seq, page == Page.AR)
        if (cands.isEmpty()) return
        val upper = page == Page.EN && (shift || caps)
        fun cased(w: String) = if (!upper) w else if (caps) w.uppercase() else w.replaceFirstChar { it.uppercase() }
        val ic = currentInputConnection ?: return
        val before = ic.getTextBeforeCursor(1, 0)?.toString().orEmpty()
        val lead = if (before.isNotEmpty() && !before[0].isWhitespace()) " " else ""
        val word = cased(cands[0])
        ic.commitText("$lead$word ", 1)
        glideLen = word.length + 1
        glideAlt = cands.map { cased(it) }
        autoUndo = null
        playSound(0)
        if (page == Page.EN && shift && !caps) { shift = false; refreshShift() }
        postUpdate()
    }

    // ---------- الإيموجي ----------
    private var emojiTab = 1

    private fun recentEmojis(): List<String> =
        prefs.getString("recent_emoji", "").orEmpty().split("|").filter { it.isNotEmpty() }

    private fun onEmoji(e: String) {
        commit()
        currentInputConnection?.commitText(e, 1)
        val list = (listOf(e) + recentEmojis().filter { it != e }).take(32)
        prefs.edit().putString("recent_emoji", list.joinToString("|")).apply()
        playSound(0)
        postUpdate()
    }

    private fun buildEmoji() {
        Emojis.load(this)
        if (emojiTab == 0 && recentEmojis().isEmpty()) emojiTab = 1
        val tabs = row().apply {
            addView(android.widget.TextView(this@KeyboardService).apply {
                text = "🔍"
                textSize = 18f
                gravity = android.view.Gravity.CENTER
                layoutParams = LinearLayout.LayoutParams(0, dp(40), 1f)
                setOnClickListener { openEmojiSearch() }
            })
            Emojis.categories.forEachIndexed { i, (icon, _) ->
                addView(android.widget.TextView(this@KeyboardService).apply {
                    text = icon
                    textSize = 18f
                    gravity = android.view.Gravity.CENTER
                    setBackgroundColor(if (i == emojiTab) 0xFF3B3F4F.toInt() else 0x00000000)
                    layoutParams = LinearLayout.LayoutParams(0, dp(40), 1f)
                    setOnClickListener { emojiTab = i; buildPage() }
                })
            }
        }
        keysBox.addView(tabs)

        val cols = 8
        val items = if (emojiTab == 0) recentEmojis() else Emojis.categories[emojiTab].second
        val grid = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        if (items.isEmpty()) {
            grid.addView(android.widget.TextView(this).apply {
                text = "ما فيه إيموجي مستخدمة لسا"
                setTextColor(0x99FFFFFF.toInt())
                gravity = android.view.Gravity.CENTER
                setPadding(0, dp(40), 0, 0)
            })
        }
        items.chunked(cols).forEach { chunk ->
            grid.addView(row().apply {
                chunk.forEach { e ->
                    addView(android.widget.TextView(this@KeyboardService).apply {
                        text = e
                        textSize = 24f
                        gravity = android.view.Gravity.CENTER
                        layoutParams = LinearLayout.LayoutParams(0, dp(44), 1f)
                        setOnClickListener {
                            performHapticFeedback(android.view.HapticFeedbackConstants.KEYBOARD_TAP)
                            onEmoji(e)
                        }
                        val tv = Emojis.toneVariants(e)
                        if (tv != null) setOnLongClickListener {
                            performHapticFeedback(android.view.HapticFeedbackConstants.LONG_PRESS)
                            showToneChooser(this, tv); true
                        }
                    })
                }
                repeat(cols - chunk.size) {
                    addView(View(this@KeyboardService).apply {
                        layoutParams = LinearLayout.LayoutParams(0, dp(44), 1f)
                    })
                }
            })
        }
        keysBox.addView(android.widget.ScrollView(this).apply {
            isVerticalScrollBarEnabled = false
            addView(grid)
        }, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(134)))

        keysBox.addView(row().apply {
            addView(key(if (lastLetterPage == Page.EN) "ABC" else "أبج", 1.5f, cSpecial, cSpecialDown, size = 14f) {
                setPage(lastLetterPage)
            })
            addView(key("␣", 5f, cKey, cKeyDown, snd = 1) { typeText(" ") })
            addView(backspaceKey())
            addView(enterKey())
        })
    }

    private fun buildSymbols(rows: List<List<String>>, toggleLabel: String, togglePage: Page) {
        val en = lastLetterPage == Page.EN
        val onSym2 = togglePage == Page.SYM1
        keysBox.addView(row().apply { rows[0].forEach { ch -> addView(symKey(ch)) } })
        keysBox.addView(row().apply { rows[1].forEach { ch -> addView(symKey(ch)) } })
        keysBox.addView(row().apply {
            addView(key(toggleLabel, 1.5f, cSpecial, cSpecialDown, size = 14f) { setPage(togglePage) })
            rows[2].forEach { ch -> addView(symKey(ch)) }
            addView(backspaceKey())
        })
        keysBox.addView(row().apply {
            addView(key(if (en) "ABC" else "أبج", 1.5f, cSpecial, cSpecialDown, size = 14f) { setPage(lastLetterPage) })
            if (onSym2) addView(symKey("«", cSpecial, cSpecialDown)) else addView(symKey(",", cSpecial, cSpecialDown))
            addView(key("12\n34", 1f, cSpecial, cSpecialDown, size = 11f) { setPage(Page.NUM) })
            addView(key(if (en) "English" else "العربية", 4f, cKey, cKeyDown, snd = 1, size = 14f,
                onLong = { showPicker() }) { typeText(" ") })
            if (onSym2) addView(symKey("»", cSpecial, cSpecialDown)) else addView(symKey(".", cSpecial, cSpecialDown))
            addView(enterKey())
        })
    }

    private fun buildNumpad() {
        val en = lastLetterPage == Page.EN
        fun nk(l: String) = key(l, 1f, cKey, cKeyDown, size = 22f, preview = false) { typeText(l) }
        fun side(l: String) = key(l, 0.6f, cSpecial, cSpecialDown, size = 18f,
            alts = { symAltsFor(l) }) { typeText(l) }
        keysBox.addView(row().apply {
            addView(side("+")); addView(nk("1")); addView(nk("2")); addView(nk("3"))
            addView(key("%", 1f, cSpecial, cSpecialDown, size = 18f, alts = { symAltsFor("%") }) { typeText("%") })
        })
        keysBox.addView(row().apply {
            addView(side("-")); addView(nk("4")); addView(nk("5")); addView(nk("6"))
            addView(key("␣", 1f, cSpecial, cSpecialDown, snd = 1) { typeText(" ") })
        })
        keysBox.addView(row().apply {
            addView(side("*")); addView(nk("7")); addView(nk("8")); addView(nk("9"))
            addView(backspaceKey().also { (it.layoutParams as LinearLayout.LayoutParams).weight = 1f })
        })
        keysBox.addView(row().apply {
            addView(key(if (en) "ABC" else "أبج", 1.4f, cSpecial, cSpecialDown, size = 14f) { setPage(lastLetterPage) })
            addView(key(",", 0.8f, cSpecial, cSpecialDown) { typeText(",") })
            addView(key("!?#", 1f, cSpecial, cSpecialDown, size = 14f) { setPage(Page.SYM1) })
            addView(nk("0"))
            addView(key("=", 0.8f, cSpecial, cSpecialDown) { typeText("=") })
            addView(key(".", 0.8f, cSpecial, cSpecialDown) { typeText(".") })
            addView(enterKey())
        })
    }

    private fun letter(ch: String, hint: String?): KeyView {
        val k = key(ch, 1f, cKey, cKeyDown, hint = hint, preview = true,
            alts = { altsFor(ch, hint) }, glide = true) { typeText(currentCase(ch)) }
        // الضغطة الطويلة تكتب الرقم
        letterKeys.add(k to ch)
        return k
    }

    private fun currentCase(ch: String) =
        if (page == Page.EN && (shift || caps)) ch.uppercase() else ch

    private fun refreshShift() {
        letterKeys.forEach { (k, ch) -> k.setLabel(currentCase(ch)) }
        shiftKey?.setLabel(if (caps) "⇪" else if (shift) "⬆" else "⇧")
    }

    private fun onShift() {
        val now = System.currentTimeMillis()
        if (caps) { caps = false; shift = false }
        else if (now - lastShiftTap < 400) { caps = true; shift = true }
        else shift = !shift
        lastShiftTap = now
        refreshShift()
    }

    private fun setPage(p: Page) {
        if (p == Page.AR || p == Page.EN) {
            lastLetterPage = p
            prefs.edit().putString("last_lang", if (p == Page.EN) "en" else "ar").apply()
        }
        if (emojiSearch && p != Page.AR && p != Page.EN) { emojiSearch = false; postUpdate() }
        page = p
        if (p != Page.AR && showHarakat) { showHarakat = false; updateSuggestions() }
        buildPage()
    }

    private fun switchLanguage() {
        shift = false; caps = false
        setPage(if (lastLetterPage == Page.AR) Page.EN else Page.AR)
    }

    private fun backspaceKey() = key("⌫", 1.5f, cSpecial, cSpecialDown, snd = 2, repeat = true) { backspace() }
    private fun enterKey() = key("↵", 1.5f, cAction, cActionDown, snd = 3) { enter() }

    // ---------- الإدخال ----------
    override fun onStartInputView(info: EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        buffer.clear()
        emojiSearch = false
        glideAlt = null
        autoUndo = null
        applyPrefs(rebuild = false)
        // نرجع دائماً لآخر لغة استخدمتها (عربي أو إنجليزي) بدل صفحة الرموز/الإيموجي
        if (::keysBox.isInitialized) {
            shift = false; caps = false; showHarakat = false; showTrans = false
            setPage(lastLetterPage)
        }
        val t = info?.inputType ?: 0
        val v = t and InputType.TYPE_MASK_VARIATION
        suggestOk = prefs.getBoolean("suggest", true) &&
            (t and InputType.TYPE_MASK_CLASS) == InputType.TYPE_CLASS_TEXT &&
            (t and InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS) == 0 &&
            v != InputType.TYPE_TEXT_VARIATION_PASSWORD &&
            v != InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD &&
            v != InputType.TYPE_TEXT_VARIATION_WEB_PASSWORD &&
            v != InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS &&
            v != InputType.TYPE_TEXT_VARIATION_URI
        postUpdate()
        captureClip()
    }

    override fun onFinishInputView(finishingInput: Boolean) {
        showTrans = false
        transToken++
        stopVoice()
        commit()
        super.onFinishInputView(finishingInput)
    }

    private fun typeText(s: String) {
        if (emojiSearch) {
            emojiQuery.append(s)
            refreshEmojiResults()
            if (page == Page.EN && shift && !caps) { shift = false; refreshShift() }
            return
        }
        glideAlt = null
        autoUndo = null
        if (mode == Mode.NORMAL) {
            if (suggestOk && s.isNotEmpty() && !isWordChar(s[0]) && prefs.getBoolean("autocorrect", false)) {
                tryAutoCorrect(s)
            }
            if (suggestOk && s.isNotEmpty() && !isWordChar(s[0])) {
                suggestions.learn(currentWord())
                learnPairBefore(false)
            }
            currentInputConnection?.commitText(s, 1)
            pendingUndo?.let { autoUndo = it; pendingUndo = null }
            postUpdate()
        } else {
            buffer.append(s)
            render()
        }
        if (page == Page.EN && shift && !caps) { shift = false; refreshShift() }
    }

    private fun render() {
        currentInputConnection?.setComposingText(TextTransform.apply(buffer.toString(), mode), 1)
    }

    private fun commit() {
        if (buffer.isNotEmpty()) {
            currentInputConnection?.finishComposingText()
            buffer.clear()
        }
    }

    private fun backspace() {
        if (emojiSearch) {
            if (emojiQuery.isNotEmpty()) emojiQuery.deleteCharAt(emojiQuery.length - 1)
            refreshEmojiResults()
            return
        }
        glideAlt = null
        val undo = autoUndo
        if (undo != null && buffer.isEmpty()) {
            autoUndo = null
            val ic = currentInputConnection
            val tail = undo[1] + undo[2]
            if (ic != null && ic.getTextBeforeCursor(tail.length, 0)?.toString() == tail) {
                ic.beginBatchEdit()
                ic.deleteSurroundingText(tail.length, 0)
                ic.commitText(undo[0] + undo[2], 1)
                ic.endBatchEdit()
                suggestions.learn(undo[0])
                postUpdate()
                return
            }
        }
        if (buffer.isNotEmpty()) {
            buffer.deleteCharAt(buffer.length - 1)
            render()
        } else {
            sendDownUpKeyEvents(KeyEvent.KEYCODE_DEL)
            postUpdate()
        }
    }

    private fun enter() {
        if (emojiSearch) { closeEmojiSearch(); return }
        if (buffer.isNotEmpty()) {
            commit() // أول ضغطة تثبّت النص
            return
        }
        val info = currentInputEditorInfo
        val action = (info?.imeOptions ?: 0) and EditorInfo.IME_MASK_ACTION
        val noAction = ((info?.imeOptions ?: 0) and EditorInfo.IME_FLAG_NO_ENTER_ACTION) != 0
        if (!noAction && action != EditorInfo.IME_ACTION_NONE && action != EditorInfo.IME_ACTION_UNSPECIFIED) {
            currentInputConnection?.performEditorAction(action)
        } else {
            sendDownUpKeyEvents(KeyEvent.KEYCODE_ENTER)
        }
    }

    private val decoder by lazy { ArabiziDecoder(this) }

    /** يحوّل النص المحدد (أو آخر نص منسوخ) من عربي بحروف إنجليزية إلى عربي. */
    private fun pasteDecodedArabizi() {
        val ic = currentInputConnection ?: return
        val sel = ic.getSelectedText(0)?.toString().orEmpty()
        val src = if (sel.isNotEmpty()) sel else {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
            cm.primaryClip?.takeIf { it.itemCount > 0 }?.getItemAt(0)?.coerceToText(this)?.toString().orEmpty()
        }
        if (src.isEmpty()) {
            android.widget.Toast.makeText(this, "حدّد نص أو انسخ نص أول", android.widget.Toast.LENGTH_SHORT).show()
            return
        }
        commit()
        ic.commitText(decoder.decode(src), 1)
        postUpdate()
    }

    /** يلصق آخر نص منسوخ بعد فك عكسه. */
    private fun pasteUnreversed() {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
        val text = cm.primaryClip?.takeIf { it.itemCount > 0 }?.getItemAt(0)?.coerceToText(this)?.toString()
        if (text.isNullOrEmpty()) {
            android.widget.Toast.makeText(this, "ما فيه نص منسوخ", android.widget.Toast.LENGTH_SHORT).show()
            return
        }
        commit()
        currentInputConnection?.commitText(TextTransform.unreverse(text), 1)
    }

    private fun nextMode() {
        val all = Mode.values()
        mode = all[(mode.ordinal + 1) % all.size]
        modeButton.text = modeIcon(mode)
        showTip(modeButton, "الوضع: ${mode.label}")
        if (mode == Mode.NORMAL) commit() else if (buffer.isNotEmpty()) render()
        postUpdate()
    }

    // ---------- أدوات الواجهة ----------
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun row() = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        layoutDirection = View.LAYOUT_DIRECTION_LTR
    }

    private fun spacer(w: Float) = View(this).apply {
        layoutParams = LinearLayout.LayoutParams(0, keyH(), w)
    }

    private fun key(
        label: String,
        weight: Float = 1f,
        color: Int = cKey,
        pressed: Int = cKeyDown,
        hint: String? = null,
        snd: Int = 0,
        size: Float = 20f,
        repeat: Boolean = false,
        preview: Boolean = false,
        alts: (() -> List<String>)? = null,
        onLong: (() -> Unit)? = null,
        altCols: Int = 8,
        altDefault: Int = 0,
        glide: Boolean = false,
        slide: Boolean = false,
        onClick: () -> Unit
    ): KeyView {
        val k = KeyView(
            this, label, hint, color, pressed, repeat, snd, preview, alts, onLong,
            { if (::overlay.isInitialized) overlay else null },
            onDown = { playSound(it) },
            onTap = onClick,
            onPick = { typeText(it) },
            altCols = altCols,
            altDefault = altDefault,
            onSlide = if (slide) ({ dir -> slideCursor(dir) }) else null,
            glide = if (glide) glideHost else null
        )
        k.textSize = size
        k.layoutParams = LinearLayout.LayoutParams(0, keyH(), weight).apply {
            setMargins(dp(2), dp(3), dp(2), dp(3))
        }
        return k
    }
}
