package com.example.reversekeyboard

/** ثيمات الكيبورد (كلها داكنة عشان النصوص البيضاء تبقى مقروءة). */
object Theme {
    class T(
        val label: String,
        val bgTop: Int, val bgBottom: Int,
        val key: Int, val keyDown: Int,
        val special: Int, val specialDown: Int,
        val action: Int, val actionDown: Int
    )

    val all = linkedMapOf(
        "blue" to T("أزرق (الافتراضي)", 0xFF1E2230.toInt(), 0xFF14161F.toInt(), 0xFF3C4254.toInt(), 0xFF5E6788.toInt(),
            0xFF2A3047.toInt(), 0xFF454F78.toInt(), 0xFF4F7CE8.toInt(), 0xFF7C9DF2.toInt()),
        "gboard" to T("رمادي (مثل Gboard)", 0xFF202124.toInt(), 0xFF1B1C1F.toInt(), 0xFF3C3F44.toInt(), 0xFF5F6368.toInt(),
            0xFF2D3036.toInt(), 0xFF4A4D55.toInt(), 0xFF5B8DEF.toInt(), 0xFF8AB4F8.toInt()),
        "black" to T("أسود (AMOLED)", 0xFF000000.toInt(), 0xFF000000.toInt(), 0xFF1F1F1F.toInt(), 0xFF3A3A3A.toInt(),
            0xFF141414.toInt(), 0xFF303030.toInt(), 0xFF3D6FE0.toInt(), 0xFF6D94EE.toInt()),
        "purple" to T("بنفسجي", 0xFF251B38.toInt(), 0xFF171022.toInt(), 0xFF3F3358.toInt(), 0xFF65558A.toInt(),
            0xFF2D2342.toInt(), 0xFF4C3F70.toInt(), 0xFF8E5BE8.toInt(), 0xFFB38BF2.toInt()),
        "green" to T("أخضر", 0xFF17281F.toInt(), 0xFF0E1914.toInt(), 0xFF2F4A3C.toInt(), 0xFF4E7A62.toInt(),
            0xFF223729.toInt(), 0xFF3C6048.toInt(), 0xFF1F9E6B.toInt(), 0xFF4CC794.toInt())
    )

    var current: T = all.getValue("blue")
        private set

    fun set(name: String?) { current = all[name] ?: all.getValue("blue") }
}
