package com.example.reversekeyboard

import android.content.Context
import android.content.SharedPreferences

/** اقتراحات إكمال الكلمة: قاموس مدمج + كلمات يتعلّمها من كتابتك (محفوظة على الجوال فقط). */
class Suggestions(private val context: Context, private val prefs: SharedPreferences) {

    private val learned = HashMap<String, Int>()

    init {
        prefs.getString("learned", "")?.lineSequence()?.forEach { line ->
            val p = line.split('\t')
            if (p.size == 2) p[1].toIntOrNull()?.let { learned[p[0]] = it }
        }
    }

    // ---------- الكلمة التالية ----------
    private val pairs = HashMap<String, HashMap<String, Int>>()

    init {
        prefs.getString("pairs", "")?.lineSequence()?.forEach { line ->
            val p = line.split('\t')
            if (p.size == 3) p[2].toIntOrNull()?.let { c -> pairs.getOrPut(p[0]) { HashMap() }[p[1]] = c }
        }
    }

    private fun pk(w: String) = if (w.all { it.code < 128 }) w.lowercase() else w

    fun learnPair(prev: String, next: String) {
        if (prev.length < 1 || next.length < 1) return
        val m = pairs.getOrPut(pk(prev)) { HashMap() }
        m[pk(next)] = (m[pk(next)] ?: 0) + 1
        if (pairs.size > 3000) pairs.remove(pairs.keys.first())
        prefs.edit().putString("pairs", pairs.entries.flatMap { (a, mm) ->
            mm.entries.map { "$a\t${it.key}\t${it.value}" }
        }.joinToString("\n")).apply()
    }

    fun predictNext(prev: String, max: Int = 3): List<String> {
        val out = LinkedHashSet<String>()
        pairs[pk(prev)]?.entries?.sortedByDescending { it.value }?.forEach { if (out.size < max) out.add(it.key) }
        val defaults = if (prev.any { it.code > 127 }) listOf("في", "من", "على", "ما", "لا")
                       else listOf("the", "to", "and", "I", "you")
        for (w in defaults) if (out.size < max) out.add(w)
        return out.toList()
    }

    private fun norm(s: String): String {
        val sb = StringBuilder()
        for (c in s) {
            if (c in 'ً'..'ٟ' || c == 'ٰ' || c == 'ـ') continue
            sb.append(
                when (c) {
                    'أ', 'إ', 'آ', 'ٱ' -> 'ا'
                    else -> c.lowercaseChar()
                }
            )
        }
        return sb.toString()
    }

    // القوائم: الكلمة الأصلية + شكلها المبسّط للمطابقة (نفس الكائن إذا ما تغيّرت)
    @Volatile private var words: Array<String> = emptyArray()
    @Volatile private var norms: Array<String> = emptyArray()

    init {
        // نبدأ بالقاموس الصغير فوراً، ثم نحمّل القواميس الكبيرة من الـ assets بخيط خلفي
        setWords((AR_WORDS.split(Regex("\\s+")) + EN_WORDS.split(Regex("\\s+"))).filter { it.isNotEmpty() })
        Thread {
            try {
                // الكلمات الشائعة فقط: القاموس الخليجي المنتقى أولاً، ثم أشهر الكلمات حسب التكرار (الغريبة والنادرة مستبعدة)
                val curated = (AR_WORDS.split(Regex("\\s+")) + EN_WORDS.split(Regex("\\s+"))).filter { it.isNotEmpty() }
                val big = ArrayList<String>(40_000)
                big.addAll(curated)
                val full = ArrayList<String>(110_000)   // القاموس الكامل (للتصحيح والكتابة بالسحب)
                full.addAll(curated)
                for ((f, cap) in listOf("ar_words.txt" to 12000, "en_words.txt" to 10000)) {
                    var cnt = 0
                    context.assets.open(f).bufferedReader(Charsets.UTF_8).useLines { lines ->
                        for (ln in lines) {
                            val w = ln.trim()
                            if (w.length < 2 || w.any { c -> c.isDigit() }) continue
                            full.add(w)
                            if (cnt < cap) { big.add(w); cnt++ }
                        }
                    }
                }
                setFull(full)
                setWords(big)
            } catch (_: Exception) {
            }
        }.start()
    }

    // ---------- القاموس الكامل: التصحيح التلقائي + الكتابة بالسحب ----------
    @Volatile private var fullWords: Array<String> = emptyArray()
    @Volatile private var fullNorms: Array<String> = emptyArray()
    @Volatile private var fullRank: HashMap<String, Int> = HashMap()

    private fun setFull(list: List<String>) {
        val rank = HashMap<String, Int>(list.size * 2)
        val w = ArrayList<String>(list.size)
        val n = ArrayList<String>(list.size)
        for (x in list) {
            val k = norm(x)
            if (rank.containsKey(k)) continue
            rank[k] = w.size
            w.add(x); n.add(k)
        }
        fullWords = w.toTypedArray(); fullNorms = n.toTypedArray(); fullRank = rank
    }

    fun isKnown(word: String): Boolean {
        val k = norm(word)
        return fullRank.containsKey(k) || learned.containsKey(if (word.all { it.code < 128 }) word.lowercase() else word)
    }

    private val AR_ALPHA = "ابتثجحخدذرزسشصضطظعغفقكلمنهويىءؤئة"
    private val EN_ALPHA = "abcdefghijklmnopqrstuvwxyz"

    /** تصحيح كلمة مكتوبة غلط (حرف واحد خطأ/زيادة/نقص/تبديل مكان). يرجع null إذا ما في تصحيح موثوق. */
    fun correct(word: String): String? {
        if (word.length < 3 || word.any { it.isDigit() } || fullRank.isEmpty()) return null
        if (isKnown(word)) return null
        if (word.length > 2 && word.all { it.isUpperCase() }) return null // اختصارات
        val key = norm(word)
        val arabic = word.any { it.code > 127 }
        val alpha = if (arabic) AR_ALPHA else EN_ALPHA
        var best = -1
        fun consider(c: String) {
            val r = fullRank[c] ?: return
            if (best < 0 || r < best) best = r
        }
        for (i in 0..key.length) {
            if (i < key.length) consider(key.removeRange(i, i + 1))
            if (i < key.length - 1) consider(key.substring(0, i) + key[i + 1] + key[i] + key.substring(i + 2))
            for (c in alpha) {
                if (i < key.length && c != key[i]) consider(key.substring(0, i) + c + key.substring(i + 1))
                consider(key.substring(0, i) + c + key.substring(i))
            }
        }
        if (best < 0) return null
        return matchCase(word, fullWords[best])
    }

    /** الكتابة بالسحب: seq = تسلسل حروف المفاتيح اللي مرّ عليها الإصبع. */
    fun glide(seq: String, arabic: Boolean, max: Int = 3): List<String> {
        val fw = fullWords; val fnorm = fullNorms
        if (seq.length < 2 || fw.isEmpty()) return emptyList()
        val first = seq[0]; val last = seq[seq.length - 1]; val last2 = seq[seq.length - 2]
        val scored = ArrayList<Pair<Int, Int>>()
        for (i in fnorm.indices) {
            val w = fnorm[i]
            if (w.length < 2 || w[0] != first) continue
            val wl = w[w.length - 1]
            if (wl != last && wl != last2) continue
            if ((w[0].code > 127) != arabic) continue
            // هل حروف الكلمة تظهر بالترتيب داخل مسار الإصبع؟
            var j = 0; var ok = true; var collapsed = 0; var prev = '\u0000'
            for (ch in w) {
                if (ch == prev) continue
                prev = ch; collapsed++
                while (j < seq.length && seq[j] != ch) j++
                if (j >= seq.length) { ok = false; break }
                j++
            }
            if (!ok) continue
            scored.add(Pair((seq.length - collapsed) * 250 + i, i))
        }
        scored.sortBy { it.first }
        return scored.take(max).map { fw[it.second] }
    }

    private fun setWords(list: List<String>) {
        val seen = HashSet<String>(list.size * 2)
        val w = ArrayList<String>(list.size)
        val n = ArrayList<String>(list.size)
        for (x in list) {
            if (!seen.add(x)) continue
            w.add(x)
            val nx = norm(x)
            n.add(if (nx == x) x else nx)
        }
        norms = n.toTypedArray()
        words = w.toTypedArray()
    }

    fun suggest(prefix: String, max: Int = 3): List<String> {
        val key = norm(prefix)
        if (key.isEmpty()) return emptyList()
        val out = LinkedHashSet<String>()
        learned.entries
            .filter { norm(it.key).startsWith(key) && norm(it.key) != key }
            .sortedByDescending { it.value }
            .forEach { if (out.size < max) out.add(it.key) }
        val n = norms
        val w = words
        var i = 0
        while (i < n.size && out.size < max) {
            if (n[i].length > key.length && n[i].startsWith(key)) out.add(w[i])
            i++
        }
        return out.map { matchCase(prefix, it) }.distinct().take(max)
    }

    private fun matchCase(prefix: String, w: String): String = when {
        prefix.length > 1 && prefix.all { it.isUpperCase() } -> w.uppercase()
        prefix.first().isUpperCase() -> w.replaceFirstChar { it.uppercase() }
        else -> w
    }

    fun learn(word: String) {
        val w = word.trim()
        if (w.length < 2 || w.any { it.isDigit() }) return
        val key = if (w.all { it.code < 128 }) w.lowercase() else w
        learned[key] = (learned[key] ?: 0) + 1
        if (learned.size > 2000) {
            learned.entries.minByOrNull { it.value }?.let { learned.remove(it.key) }
        }
        prefs.edit().putString("learned", learned.entries.joinToString("\n") { "${it.key}\t${it.value}" }).apply()
    }

    companion object {
        const val AR_WORDS = """
في من على إلى الى عن مع هذا هذه هذي ذلك هاذا التي الذي هو هي هم أنا انا أنت انت نحن كان كانت يكون ليس لا نعم ما ماذا كيف
لماذا ليش وين متى مين شو ايش ويش وش زي مثل كل بعض كثير قليل جدا اليوم أمس امس بكرة غدا الان الآن بعد قبل عند عندي عندك
لك لي له لها لهم بس لكن لأن لان أو او ثم كمان برضو أيضا ايضا مرة مره واحد اثنين ثلاثة أربعة خمسة ستة سبعة ثمانية تسعة عشرة
السلام عليكم وعليكم ورحمة الله وبركاته مرحبا أهلا اهلا وسهلا هلا والله حياك الله يعطيك العافية يعافيك شكرا شكراً جزاك خير
يجزاك الخير مشكور تسلم يسلمك تمام طيب ممتاز حلو حبيبي حبيبتي أخوي اخوي أختي اختي أبوي ابوي أمي امي صديقي صاحبي
أريد اريد أبغى ابغى ابغا أبغا ابي أبي أبغاك ابغاك أروح اروح أجي اجي أكل اكل أشرب اشرب أقول اقول أشوف اشوف أعرف اعرف أقدر اقدر
أبغي ابغي أحب احب أعطني اعطني خلني خلنا خله خليه خليها تعال تعالي روح روحي اذهب اجلس قم تفضل تفضلي
اشتغل اشتغلت شغل شغلي عمل دوام اجتماع موعد مشغول فاضي متاح متأخر مبكر سريع بطيء قريب بعيد
البيت بيت المدرسة مدرسة الجامعة جامعة المستشفى مستشفى المطار مطار السيارة سيارة الشارع شارع السوق سوق المطعم مطعم
جوال جوالي الجوال رسالة رسائل اتصال اتصل اتصلت كلمني كلمتك أرسل ارسل أرسلت ارسلت رد ردي رديت واتس واتساب
الله إن ان شاء إنشاء انشاء ان شاء الله ماشاء ما شاء الله الحمد لله الحمدلله بسم الله لا حول ولا قوة إلا بالله
صباح الخير مساء الخير صباح النور مساء النور تصبح على خير ليلة سعيدة عيد مبارك رمضان كريم كل عام وأنتم بخير
مبروك الف مبروك عقبال ان شاء الله يارب اللهم آمين امين صلى عليه وسلم
آسف اسف عفوا عذرا معذرة سامحني لو سمحت من فضلك رجاء رجاءً لا بأس ولا يهمك ما في مشكلة مشكلة
فعلا فعلاً صراحة بصراحة طبعا طبعاً اكيد أكيد ممكن مستحيل صح غلط صحيح خطأ احتمال ربما يمكن
الحين الحين دحين توه توني لسه لسا خلاص بعدين قبلين دايما دائما أحيانا احيانا أبدا ابدا دايم
هناك هنا هنا هناك فوق تحت داخل خارج يمين يسار قدام ورا وراء جنب
مع السلامة في أمان الله الله يوفقك يوفقك الله يحفظك يحفظك الله ربي يهديك يهديك الله الله يرحمه
أخبارك اخبارك شلونك كيفك كيف حالك عساك بخير عسى الله بخير الحمد
ولد بنت رجل امرأة طفل أطفال ناس شخص أهل عيلة عائلة زوجتي زوجي ابني بنتي
ماء قهوة شاي أكل اكل غداء عشاء فطور جوع جوعان عطشان تعبان نعسان زعلان فرحان
وقت ساعة دقيقة يوم أسبوع شهر سنة أمس الليلة الليل النهار الصبح الظهر العصر المغرب العشاء
مال فلوس ريال ريالات دينار درهم سعر غالي رخيص رخيصة دفع ادفع حساب بنك تحويل
شكرا لك شكرا جزيلا شكراً جزيلاً بارك الله فيك الله يبارك فيك وفيك بارك
سؤال جواب سؤالي جوابك معلومة معلومات موضوع مهم ضروري سهل صعب جديد قديم كبير صغير طويل قصير
اللغة العربية الإنجليزية انجليزي عربي ترجمة كلمة كلمات جملة نص كتابة قراءة كيبورد لوحة مفاتيح
"""
        private const val EN_WORDS = """
the of and to a in is it you that he was for on are with as I his they be at one have this from or had by hot but what some we can out
other were all there when up use your how said an each she which do their time if will way about many then them write would like so these her long make
thing see him two has look more day could go come did number sound no most people my over know water than call first who may down side been now find
hello hi hey thanks thank you please okay ok yes sorry good morning night evening afternoon today tomorrow yesterday tonight love friend friends brother sister
mother father home work school phone message messages call meeting weekend because before after something anything everything someone everyone really actually
probably definitely maybe already always never sometimes where while whatever however important question answer problem problems different another between
through during without within around against follow again place right think great little world still every found those under never last should where before
want need going gonna wanna should would could might must shall please welcome congratulations birthday happy sad angry tired hungry busy free ready late early soon
let lets let's don't doesn't didn't can't won't isn't aren't wasn't weren't i'm i've i'll i'd you're you've you'll we're they're it's that's what's there's
text email number address name city country money price cheap expensive pay paid buy bought sell sold order delivery restaurant coffee tea food lunch dinner breakfast
tomorrow monday tuesday wednesday thursday friday saturday sunday january february march april june july august september october november december
english arabic language keyboard typing write writing read reading speak speaking listen listening learn learning teach teaching study studying
"""
    }
}
