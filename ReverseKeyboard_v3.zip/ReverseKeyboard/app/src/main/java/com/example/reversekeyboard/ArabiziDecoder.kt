package com.example.reversekeyboard

import android.content.Context

/**
 * يحوّل العربي المكتوب بحروف إنجليزية (arabizi) لحروف عربية:  tmam ← تمام ، 7abibi ← حبيبي
 * الطريقة: نبني "هيكل صوامت" لكل كلمة عربية من القاموس ونطابقه مع هيكل الكلمة المكتوبة،
 * ثم نختار الأقرب كتابةً والأكثر تكراراً. الكلمات الإنجليزية الشائعة تبقى كما هي.
 */
class ArabiziDecoder(private val context: Context) {

    private var arWords: Array<String> = emptyArray()
    private var forms: Array<String> = emptyArray()
    private var buckets: HashMap<String, IntArray> = HashMap()
    private var enCommon: HashSet<String> = HashSet()
    private var ready = false

    @Synchronized
    private fun ensure() {
        if (ready) return
        val ar = ArrayList<String>(60_000)
        try {
            context.assets.open("ar_words.txt").bufferedReader(Charsets.UTF_8).useLines { l ->
                l.forEach { if (it.isNotBlank()) ar.add(it.trim()) }
            }
        } catch (_: Exception) {}
        ar.addAll(Suggestions.AR_WORDS.split(Regex("\\s+")).filter { it.isNotEmpty() })
        val seen = HashSet<String>()
        val list = ar.filter { seen.add(it) }
        arWords = list.toTypedArray()
        forms = Array(arWords.size) { TextTransform.arabizi(arWords[it]).lowercase() }

        val tmp = HashMap<String, ArrayList<Int>>()
        for (i in arWords.indices) {
            val w = arWords[i]
            val k = skelAr(w)
            if (k.isEmpty()) continue
            val keys = if (w.last() == 'ة' || w.last() == 'ه') listOf(k, k.dropLast(1)) else listOf(k)
            for (kk in keys) {
                if (kk.isEmpty()) continue
                val b = tmp.getOrPut(kk) { ArrayList() }
                if (b.size < 40) b.add(i)
            }
        }
        buckets = HashMap<String, IntArray>(tmp.size * 2).also { m -> tmp.forEach { (k, v) -> m[k] = v.toIntArray() } }

        try {
            var n = 0
            context.assets.open("en_words.txt").bufferedReader(Charsets.UTF_8).useLines { l ->
                for (w in l) { if (n++ >= 15_000) break; enCommon.add(w.trim()) }
            }
        } catch (_: Exception) {}
        ready = true
    }

    private fun skelAr(w: String): String {
        val sb = StringBuilder()
        for (c in w) {
            when (c) {
                'ب' -> sb.append('b')
                'ت', 'ث', 'ط', 'ظ' -> sb.append('t')
                'ج' -> sb.append('j')
                'ح', 'ه', 'ة' -> sb.append('h')
                'خ' -> sb.append('x')
                'د', 'ذ', 'ض' -> sb.append('d')
                'ر' -> sb.append('r')
                'ز' -> sb.append('z')
                'س', 'ص' -> sb.append('s')
                'ش' -> sb.append('S')
                'ع' -> sb.append('3')
                'غ' -> sb.append('G')
                'ف' -> sb.append('f')
                'ق' -> sb.append('Q')
                'ك' -> sb.append('k')
                'ل' -> sb.append('l')
                'م' -> sb.append('m')
                'ن' -> sb.append('n')
                else -> {}
            }
        }
        return sb.toString()
    }

    private fun skelLat(word: String): String {
        var s = word.lowercase()
            .replace("3'", "G").replace("7'", "x").replace("9'", "d").replace("6'", "t").replace("'", "")
            .replace("sh", "S").replace("ch", "S").replace("th", "t").replace("kh", "x")
            .replace("gh", "G").replace("dh", "d")
        val sb = StringBuilder()
        for (c in s) {
            when (c) {
                'b', 'p' -> sb.append('b')
                't', '6' -> sb.append('t')
                'j' -> sb.append('j')
                'h', '7' -> sb.append('h')
                '5', 'x' -> sb.append('x')
                'd' -> sb.append('d')
                'r' -> sb.append('r')
                'z' -> sb.append('z')
                's', '9' -> sb.append('s')
                'S' -> sb.append('S')
                '3' -> sb.append('3')
                'G' -> sb.append('G')
                'f', 'v' -> sb.append('f')
                'q', 'g', '8' -> sb.append('Q')
                'k', 'c' -> sb.append('k')
                'l' -> sb.append('l')
                'm' -> sb.append('m')
                'n' -> sb.append('n')
                else -> {}  // حروف العلة و 2
            }
        }
        return sb.toString()
    }

    // ---------- مسافة مرجّحة: حروف العلة القصيرة رخيصة، والصوامت المتقاربة (s/9، t/6، h/7) رخيصة ----------
    private fun isV(c: Char) = c in "aeiouyw"
    private fun cls(c: Char) = when (c) { 'a', 'e' -> 0; 'i', 'y' -> 1; else -> 2 }

    private fun indel(c: Char) = when (c) {
        'a', 'e', 'o', 'u' -> 0.3
        'i', 'y' -> 0.6
        'w' -> 0.5
        else -> 1.0
    }

    private fun sub(a: Char, b: Char): Double {
        if (a == b) return 0.0
        if (isV(a) && isV(b)) return if (cls(a) == cls(b)) 0.15 else 0.5
        val p = "$a$b"
        val q = "$b$a"
        for (e in EQ) if (e == p || e == q) return if (e == "ah" || e == "ha") 0.4 else 0.3
        return 1.0
    }

    private fun wdist(a: String, b: String): Double {
        val dp = DoubleArray(b.length + 1)
        for (j in 1..b.length) dp[j] = dp[j - 1] + indel(b[j - 1])
        for (i in 1..a.length) {
            var prev = dp[0]
            dp[0] += indel(a[i - 1])
            for (j in 1..b.length) {
                val tmp = dp[j]
                dp[j] = minOf(dp[j] + indel(a[i - 1]), dp[j - 1] + indel(b[j - 1]), prev + sub(a[i - 1], b[j - 1]))
                prev = tmp
            }
        }
        return dp[b.length]
    }

    /** تحويل حرف بحرف للكلمات اللي ما لقينا لها مطابق في القاموس. */
    private fun letterByLetter(word: String): String {
        val s = word.lowercase()
        val sb = StringBuilder()
        var i = 0
        while (i < s.length) {
            val c = s[i]
            val two = if (i + 1 < s.length) s.substring(i, i + 2) else ""
            when {
                two == "sh" || two == "ch" -> { sb.append('ش'); i += 2; continue }
                two == "th" -> { sb.append('ث'); i += 2; continue }
                two == "kh" -> { sb.append('خ'); i += 2; continue }
                two == "gh" -> { sb.append('غ'); i += 2; continue }
                two == "dh" -> { sb.append('ذ'); i += 2; continue }
                two == "aa" -> { sb.append('ا'); i += 2; continue }
                two == "ee" || two == "ii" -> { sb.append('ي'); i += 2; continue }
                two == "oo" || two == "ou" || two == "uu" -> { sb.append('و'); i += 2; continue }
            }
            sb.append(
                when (c) {
                    'a' -> if (i == 0 || i == s.length - 1) "ا" else ""
                    'e', 'i' -> if (i == s.length - 1) "ي" else ""
                    'o', 'u' -> if (i == s.length - 1) "و" else ""
                    'y' -> "ي"
                    'w' -> "و"
                    'b', 'p' -> "ب"
                    't' -> "ت"
                    'j' -> "ج"
                    'h' -> "ه"
                    'd' -> "د"
                    'r' -> "ر"
                    'z' -> "ز"
                    's' -> "س"
                    'f', 'v' -> "ف"
                    'q', 'g' -> "ق"
                    'k', 'c' -> "ك"
                    'l' -> "ل"
                    'm' -> "م"
                    'n' -> "ن"
                    'x' -> "كس"
                    '2' -> "ء"
                    '3' -> "ع"
                    '5' -> "خ"
                    '6' -> "ط"
                    '7' -> "ح"
                    '8' -> "ق"
                    '9' -> "ص"
                    else -> c.toString()
                }
            )
            i++
        }
        return sb.toString()
    }

    private fun decodeWord(word: String): String {
        val low = word.lowercase().trim('\'')
        SPECIAL[low]?.let { return it }
        val hasDigit = low.any { it in "235678 9".replace(" ", "") }
        val skel = skelLat(low)
        var best = -1
        var bestScore = Double.MAX_VALUE
        var bestD = 9.0
        buckets[skel]?.let { b ->
            for (idx in b) {
                val d = wdist(low, forms[idx])
                val hamza = if ('2' !in low && arWords[idx].any { it in "أإؤئء" }) 0.15 else 0.0
                val sc = d + 0.12 * Math.log(idx + 2.0) + hamza
                if (sc < bestScore) { bestScore = sc; best = idx; bestD = d }
            }
        }
        if (!hasDigit) {
            if (best >= 0 && bestD == 0.0 && best < 8_000) return arWords[best]
            if (best >= 0 && bestD <= 0.35 && best < 20_000 && !(low.length <= 2 && low in enCommon)) return arWords[best]
            if (low in enCommon) return word
        }
        if (best >= 0) return arWords[best]
        return letterByLetter(low)
    }

    fun decode(text: String): String {
        ensure()
        return Regex("[A-Za-z0-9']*[A-Za-z][A-Za-z0-9']*").replace(text) { decodeWord(it.value) }
    }

    companion object {
        private val EQ = listOf("s9", "t6", "h7", "qg", "q8", "g8", "z6", "d9", "k5", "3a", "ah")
        private val SPECIAL = mapOf("ya" to "يا", "wa" to "و", "w" to "و", "y" to "يا")
    }
}
