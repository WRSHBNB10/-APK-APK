package com.example.reversekeyboard

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.widget.LinearLayout
import android.view.View
import android.widget.FrameLayout
import android.widget.TextView

/**
 * مفتاح بشكل Gboard: ضغط بصري، فقاعة معاينة فوق الحرف، نافذة بدائل عند الضغطة الطويلة
 * (حرّك إصبعك واختر ثم ارفع)، رقم صغير فوق المفتاح، وتكرار للحذف.
 */
interface GlideHost {
    fun glideEnabled(): Boolean
    fun glideStart(rawX: Float, rawY: Float)
    fun glideMove(rawX: Float, rawY: Float)
    fun glideEnd()
    fun glideCancel()
}

class KeyView(
    context: Context,
    text: String,
    private val hintText: String?,
    private val normalColor: Int,
    private val pressedColor: Int,
    private val repeatable: Boolean,
    private val soundType: Int,
    private val showPreview: Boolean,
    private val altsProvider: (() -> List<String>)?,
    private val onLong: (() -> Unit)?,
    private val overlayProvider: () -> FrameLayout?,
    private val onDown: (Int) -> Unit,
    private val onTap: () -> Unit,
    private val onPick: (String) -> Unit,
    private val altCols: Int = 8,
    private val altDefault: Int = 0,
    private val onSlide: ((Int) -> Unit)? = null,
    private val glide: GlideHost? = null
) : TextView(context) {

    private val uiHandler = Handler(Looper.getMainLooper())
    private val d = resources.displayMetrics.density
    private val bg = GradientDrawable().apply {
        setColor(normalColor)
        cornerRadius = 10f * d
    }
    private val shadow = GradientDrawable().apply {
        setColor(0xFF0B0D14.toInt())
        cornerRadius = 10f * d
    }
    private val hintPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0x99FFFFFF.toInt()
        textSize = 10f * resources.displayMetrics.scaledDensity
        typeface = Typeface.DEFAULT
    }

    private var consumed = false
    private var down = false
    private var gliding = false
    private var downRawX = 0f
    private var downRawY = 0f
    private var slideAnchor = 0f

    private var previewView: View? = null
    private var altView: View? = null
    private var altCells: List<TextView> = emptyList()
    private var alts: List<String> = emptyList()
    private var altLeft = 0
    private var cellW = (38 * d).toInt()
    private val cellH = (52 * d).toInt()
    private var selected = 0
    private var lastRawX = 0f
    private var lastRawY = 0f
    private var altTop = 0
    private var colsUsed = 1

    private val longPress = Runnable {
        if (!down) return@Runnable
        val list = altsProvider?.invoke().orEmpty()
        if (list.isNotEmpty()) {
            consumed = true
            dismissPreview()
            showAlts(list)
        } else if (onLong != null) {
            consumed = true
            onLong.invoke()
        }
    }

    private val repeat = object : Runnable {
        override fun run() {
            if (!down) return
            consumed = true
            onDown(soundType)
            onTap()
            uiHandler.postDelayed(this, 55)
        }
    }

    init {
        this.text = text
        gravity = Gravity.CENTER
        setTextColor(0xFFF2F4FA.toInt())
        textSize = 21f
        includeFontPadding = false
        val layers = android.graphics.drawable.LayerDrawable(arrayOf(shadow, bg))
        layers.setLayerInset(1, 0, 0, 0, (2 * d).toInt())
        background = layers
        setPadding(0, 0, 0, (2 * d).toInt())
    }

    fun setLabel(s: String) { text = s }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (hintText != null) {
            canvas.drawText(hintText, width - hintPaint.measureText(hintText) - 6 * d, 12 * d, hintPaint)
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        lastRawX = e.rawX
        lastRawY = e.rawY
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                down = true
                consumed = false
                gliding = false
                downRawX = e.rawX; downRawY = e.rawY
                slideAnchor = e.rawX
                bg.setColor(pressedColor)
                onDown(soundType)
                performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
                if (showPreview) showPreviewBubble()
                if (altsProvider != null) uiHandler.postDelayed(longPress, 350)
                else if (onLong != null) uiHandler.postDelayed(longPress, 500)
                if (repeatable) uiHandler.postDelayed(repeat, 420)
            }
            MotionEvent.ACTION_MOVE -> {
                if (altView != null) {
                    updateSelection(e.rawX, e.rawY)
                } else if (gliding) {
                    glide?.glideMove(e.rawX, e.rawY)
                } else if (onSlide != null && down) {
                    val step = 16 * d
                    var dx = e.rawX - slideAnchor
                    while (Math.abs(dx) >= step) {
                        val sgn = if (dx > 0) 1 else -1
                        if (!consumed) { consumed = true; uiHandler.removeCallbacks(longPress); dismissPreview() }
                        onSlide.invoke(sgn)
                        slideAnchor += sgn * step
                        dx = e.rawX - slideAnchor
                    }
                } else if (down && glide != null && glide.glideEnabled() &&
                    (e.x < -dpf(6) || e.y < -dpf(6) || e.x > width + dpf(6) || e.y > height + dpf(6))) {
                    gliding = true
                    consumed = true
                    uiHandler.removeCallbacks(longPress)
                    dismissPreview()
                    glide.glideStart(downRawX, downRawY)
                    glide.glideMove(e.rawX, e.rawY)
                } else if (down && (e.x < -dpf(10) || e.y < -dpf(10) || e.x > width + dpf(10) || e.y > height + dpf(10))) {
                    cancel()
                }
            }
            MotionEvent.ACTION_UP -> {
                if (gliding) {
                    gliding = false
                    glide?.glideEnd()
                    cancel()
                } else if (altView != null) {
                    val pick = alts.getOrNull(selected)
                    cancel()
                    if (pick != null) onPick(pick)
                } else {
                    val fire = down && !consumed
                    cancel()
                    if (fire) onTap()
                }
            }
            MotionEvent.ACTION_CANCEL -> {
                if (gliding) { gliding = false; glide?.glideCancel() }
                cancel()
            }
        }
        return true
    }

    private fun dpf(v: Int) = v * d

    private fun cancel() {
        down = false
        uiHandler.removeCallbacks(longPress)
        uiHandler.removeCallbacks(repeat)
        bg.setColor(normalColor)
        dismissPreview()
        dismissAlts()
    }

    override fun onDetachedFromWindow() {
        cancel()
        super.onDetachedFromWindow()
    }

    // ---------- فقاعة المعاينة (داخل نافذة الكيبورد نفسها) ----------
    private fun placeInOverlay(v: View, w: Int, h: Int, xWanted: Int, gap: Int): Boolean {
        val ov = overlayProvider() ?: return false
        val kl = IntArray(2); getLocationInWindow(kl)
        val ol = IntArray(2); ov.getLocationInWindow(ol)
        val maxX = maxOf(0, ov.width - w)
        val x = (xWanted - ol[0]).coerceIn(0, maxX)
        val y = maxOf(0, kl[1] - ol[1] - h - gap)
        ov.addView(v, FrameLayout.LayoutParams(w, h).apply {
            gravity = Gravity.TOP or Gravity.LEFT
            leftMargin = x
            topMargin = y
        })
        return true
    }

    private fun showPreviewBubble() {
        try {
            val w = maxOf(width + (14 * d).toInt(), (48 * d).toInt())
            val h = (56 * d).toInt()
            val tv = TextView(context).apply {
                this.text = this@KeyView.text
                gravity = Gravity.CENTER
                textSize = 28f
                setTextColor(0xFFFFFFFF.toInt())
                includeFontPadding = false
                background = GradientDrawable().apply {
                    setColor(0xFF5A6078.toInt()); cornerRadius = 10 * d
                }
            }
            val kl = IntArray(2); getLocationInWindow(kl)
            if (placeInOverlay(tv, w, h, kl[0] + width / 2 - w / 2, (2 * d).toInt())) previewView = tv
        } catch (_: Exception) {
            previewView = null
        }
    }

    private fun dismissPreview() {
        previewView?.let { (it.parent as? android.view.ViewGroup)?.removeView(it) }
        previewView = null
    }

    // ---------- نافذة البدائل (شبكة، مثل Gboard) ----------
    private fun display(s: String) =
        if (s.length == 1 && Character.getType(s[0]) == Character.NON_SPACING_MARK.toInt()) "\u25CC$s" else s

    // مواضع الخلايا (صف، عمود) لكل عنصر
    private var cellPos: List<IntArray> = emptyList()
    private var rowsUsed = 1

    /** ترتيب Gboard/AOSP: الأول عند عمود المفتاح ثم يمين/يسار بالتناوب، والصف الأول الأقرب للمفتاح */
    private fun layoutPositions(n: Int, keyCenterX: Float, screenW: Int): Pair<List<IntArray>, IntArray> {
        if (altDefault > 0) { // شبكة قديمة (الحركات): صفوف من اليسار لليمين
            val cols = minOf(altCols, n)
            return Pair(List(n) { intArrayOf(it / cols, it % cols) }, intArrayOf((n + cols - 1) / cols, cols, 0))
        }
        // Gboard: حتى 5 عناصر في صف واحد، وغير ذلك صفّان متوازنان
        val screenCols = maxOf(1, (screenW - 8 * d).toInt() / cellW)
        val maxCols = minOf(screenCols, if (n <= 5) n else maxOf(5, (n + 1) / 2))
        val rows = (n + maxCols - 1) / maxCols
        val cols = (n + rows - 1) / rows
        // هامش نصف خلية عند الحواف (مثل Gboard)
        val maxLeftByScreen = ((keyCenterX - cellW) / cellW).toInt().coerceAtLeast(0)
        val maxRightByScreen = ((screenW - keyCenterX - cellW) / cellW).toInt().coerceAtLeast(0)
        val pos = ArrayList<IntArray>()
        var minOff = 0
        val rowOffsets = ArrayList<List<Int>>()
        var remaining = n
        for (r in 0 until rows) {
            val cnt = minOf(cols, remaining); remaining -= cnt
            val offs = ArrayList<Int>()
            var l = 0; var rt = 0
            offs.add(0)
            var turnRight = true
            while (offs.size < cnt) {
                if (turnRight) {
                    if (rt < maxRightByScreen) { rt++; offs.add(rt) }
                    else if (l < maxLeftByScreen) { l++; offs.add(-l) }
                    else break
                } else {
                    if (l < maxLeftByScreen) { l++; offs.add(-l) }
                    else if (rt < maxRightByScreen) { rt++; offs.add(rt) }
                    else break
                }
                turnRight = !turnRight
            }
            rowOffsets.add(offs)
            minOff = minOf(minOff, offs.minOrNull() ?: 0)
        }
        for (r in 0 until rows) for (o in rowOffsets[r]) pos.add(intArrayOf(rows - 1 - r, o - minOff))
        var maxCol = 0
        for (p in pos) maxCol = maxOf(maxCol, p[1])
        return Pair(pos, intArrayOf(rows, maxCol + 1, -minOff))
    }

    private fun showAlts(list: List<String>) {
        try {
            alts = list
            cellW = width.coerceIn((36 * d).toInt(), (46 * d).toInt())
            val pad = (4 * d).toInt()
            val ov = overlayProvider() ?: return
            val kl = IntArray(2); getLocationInWindow(kl)
            val ol = IntArray(2); ov.getLocationInWindow(ol)
            val os = IntArray(2); ov.getLocationOnScreen(os)
            val keyCenter = (kl[0] - ol[0] + width / 2f)
            val (pos, dims) = layoutPositions(list.size, keyCenter, ov.width)
            cellPos = pos
            val rows = dims[0]; val cols = dims[1]; val keyColIdx = dims[2]
            rowsUsed = rows; colsUsed = cols
            val w = cols * cellW + pad * 2
            val h = rows * cellH + pad * 2
            val box = FrameLayout(context).apply {
                layoutDirection = LAYOUT_DIRECTION_LTR
                background = GradientDrawable().apply {
                    setColor(0xFF44464F.toInt()); cornerRadius = if (rows == 1) h / 2f else 26 * d
                }
            }
            val cells = ArrayList<TextView>()
            for (i in list.indices) {
                val tv = TextView(context).apply {
                    this.text = display(list[i])
                    gravity = Gravity.CENTER
                    textSize = 22f
                    includeFontPadding = false
                    setTextColor(0xFFFFFFFF.toInt())
                }
                box.addView(tv, FrameLayout.LayoutParams(cellW, cellH).apply {
                    gravity = Gravity.TOP or Gravity.LEFT
                    leftMargin = pad + pos[i][1] * cellW
                    topMargin = pad + pos[i][0] * cellH
                })
                cells.add(tv)
            }
            altCells = cells
            // عمود المفتاح داخل الصندوق يطابق مركز المفتاح
            val wanted = (keyCenter - cellW / 2f - pad - keyColIdx * cellW).toInt() + ol[0]
            val xRel = (wanted - ol[0]).coerceIn(0, maxOf(0, ov.width - w))
            val yRel = maxOf(0, kl[1] - ol[1] - h - (4 * d).toInt())
            if (placeInOverlay(box, w, h, wanted, (4 * d).toInt())) {
                altView = box
                altLeft = os[0] + xRel + pad
                altTop = os[1] + yRel + pad
                selected = altDefault.coerceIn(0, list.size - 1)
                highlight()
            }
        } catch (_: Exception) {
            altView = null
        }
    }

    private fun highlight() {
        altCells.forEachIndexed { i, tv ->
            val on = i == selected
            tv.setTextColor(if (on) 0xFF101218.toInt() else 0xFFFFFFFF.toInt())
            tv.background = if (on) GradientDrawable().apply {
                setColor(0xFF8AB4F8.toInt()); shape = GradientDrawable.OVAL
            } else null
        }
    }

    private fun updateSelection(rawX: Float, rawY: Float) {
        if (altCells.isEmpty() || cellPos.size != altCells.size) return
        val col = ((rawX - altLeft) / cellW).toInt().coerceIn(0, colsUsed - 1)
        val row = ((rawY - altTop) / cellH).toInt().coerceIn(0, rowsUsed - 1)
        var best = -1; var bd = Int.MAX_VALUE
        for (i in cellPos.indices) {
            val dd = Math.abs(cellPos[i][0] - row) * 3 + Math.abs(cellPos[i][1] - col)
            if (dd < bd) { bd = dd; best = i }
        }
        if (best >= 0) selected = best
        highlight()
    }

    private fun dismissAlts() {
        altView?.let { (it.parent as? android.view.ViewGroup)?.removeView(it) }
        altView = null
        altCells = emptyList()
    }
}

/** أثر إصبع الكتابة بالسحب */
class TrailView(context: Context) : View(context) {
    private val pts = ArrayList<FloatArray>()
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 6f * resources.displayMetrics.density
        color = 0xCC8AB4F8.toInt()
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    fun add(x: Float, y: Float) { pts.add(floatArrayOf(x, y)); invalidate() }
    override fun onDraw(canvas: Canvas) {
        if (pts.size < 2) return
        val l = IntArray(2); getLocationOnScreen(l)
        val path = android.graphics.Path()
        path.moveTo(pts[0][0] - l[0], pts[0][1] - l[1])
        for (i in 1 until pts.size) path.lineTo(pts[i][0] - l[0], pts[i][1] - l[1])
        canvas.drawPath(path, paint)
    }
}
